import sys
import urllib.parse
import json
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

# --- 1. CONFIGURATION ---
ADDON = xbmcaddon.Addon()
try:
    HANDLE = int(sys.argv[1])
except:
    HANDLE = -1

DEFAULT_BACKDROP = "https://www.sunnxt.com/images/logins_bgimg.jpg"
DEFAULT_ICON = "https://www.sunnxt.com/images/logo/logo.png"

# Headers for Navigation
NAV_HEADERS = {
    'accept': '*/*',
    'accept-encoding': 'gzip, deflate, br, zstd',
    'accept-language': 'en',
    'cache-control': 'no-cache',
    'contentlanguage': 'malayalam',
    'cookie': 'sessionid=hzyp3osrklrt7j2kvpcywz8clkx62d6y',
    'origin': 'https://www.sunnxt.com',
    'referer': 'https://www.sunnxt.com/',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'x-myplex-platform': 'browser',
    'x-ucv': '5'
}

# Headers for Search & Playback (Android API)
PLAY_HEADERS = {
    'Accept-Encoding': 'gzip',
    'Accept-Language': 'en',
    'AppVersion': '200329',
    'clientKey': 'd99d1a8dd9f8da3a5ce7b1c1f28469216dc5c9ee50c948b66941421f5c58e0ab',
    'Connection': 'Keep-Alive',
    'ContentLanguage': 'malayalam',
    'Host': 'api.sunnxt.com',
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; 23116PN5BC Build/PQ3A.190705.01301014)',
    'X-myplex-maturity-level': '',
    'X-myplex-platform': 'android',
    'x-ucv': '5'
}

def log(msg):
    xbmc.log(f"SUNNXT_DEBUG >> {msg}", xbmc.LOGINFO)

def add_dir(name, query, thumb=None, isFolder=True):
    url = f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"
    item = xbmcgui.ListItem(label=name)
    img_thumb = thumb if thumb else DEFAULT_ICON
    img_fanart = thumb if thumb else DEFAULT_BACKDROP
    item.setArt({
        'thumb': img_thumb,
        'icon': img_thumb,
        'fanart': img_fanart
    })
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=isFolder)

# --- 2. SEARCH FUNCTIONS ---

def search_menu():
    kb = xbmc.Keyboard('', 'Search SunNXT')
    kb.doModal()
    
    if kb.isConfirmed():
        query = kb.getText()
        if query:
            list_search_results(query, '1')

def list_search_results(query, start_index):
    safe_query = urllib.parse.quote(query)
    # Android Search API
    url = f"https://api.sunnxt.com/content/v3/search/?fields=images,generalInfo,globalServiceId,publishingHouse,relatedCast,contents&level=dynamic&query={safe_query}&startIndex={start_index}&count=12&type=movie&searchFields=title&network=wifi"
    
    try:
        r = requests.get(url, headers=PLAY_HEADERS).json()
        results = r.get('results', [])
        
        if not results:
            xbmcgui.Dialog().notification('SunNXT', 'No results found', xbmcgui.NOTIFICATION_INFO)
            return

        for item in results:
            g = item.get('generalInfo')
            if not g: continue 

            title = g.get('title', 'Unknown')
            _id = g.get('_id')
            # Updated to pull briefDescription if description is missing
            description = g.get('description') or g.get('briefDescription', '')
            media_type = g.get('type', 'movie')
            
            # Image Handling
            images = item.get('images', {}).get('values', [])
            thumb = DEFAULT_ICON
            if images:
                thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), None)
                if not thumb:
                    thumb = images[0].get('link')
            
            gid = item.get('globalServiceId')

            # Logic: If it has a globalServiceId, it's usually a Show. Otherwise Movie.
            if media_type == 'movie' or (not gid and _id):
                action_query = {'action': 'play', 'id': _id, 'title': title, 'thumb': thumb}
                
                list_item = xbmcgui.ListItem(label=title)
                list_item.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
                
                info_tag = list_item.getVideoInfoTag()
                info_tag.setTitle(title)
                info_tag.setPlot(description)
                info_tag.setMediaType('movie')
                
                list_item.setProperty('IsPlayable', 'true')
                
                item_url = f"{sys.argv[0]}?{urllib.parse.urlencode(action_query)}"
                xbmcplugin.addDirectoryItem(HANDLE, item_url, list_item, isFolder=False)
            
            elif gid:
                action_query = {'action': 'list_episodes', 'gid': gid, 'lang': 'malayalam', 'start': '1'}
                add_dir(f"[TV] {title}", action_query, thumb, isFolder=True)

        if len(results) >= 12:
            next_start = int(start_index) + 1
            next_query = {'action': 'list_search_results', 'query': query, 'start': str(next_start)}
            add_dir("[COLOR gold]Next Page >>>[/COLOR]", next_query, isFolder=True)

    except Exception as e:
        log(f"Search Error: {str(e)}")
        xbmcgui.Dialog().notification('Error', 'Search Failed', xbmcgui.NOTIFICATION_ERROR)
    
    xbmcplugin.endOfDirectory(HANDLE)

# --- 3. NAVIGATION ---

def root_menu():
    # Added Settings button to manual list
    add_dir("[COLOR orange][B]Add-on Settings[/B][/COLOR]", {'action': 'open_settings'}, isFolder=False)
    add_dir("[COLOR green][B]Search SunNXT[/B][/COLOR]", {'action': 'search_menu'}, isFolder=True)
    languages = ["malayalam", "tamil", "telugu", "kannada", "hindi", "bengali", "marathi", "english"]
    for lang in languages:
        query = {'action': 'list_lang_sections', 'lang': lang}
        add_dir(lang.capitalize(), query, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_lang_sections(lang):
    add_dir("[COLOR yellow]Movies[/COLOR]", {'action': 'list_group', 'lang': lang, 'group': 'portalMovies'}, isFolder=True)
    add_dir("[COLOR cyan]TV Shows[/COLOR]", {'action': 'list_group', 'lang': lang, 'group': 'portalTvShows'}, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_group(lang, group):
    url = f"https://pwaapi.sunnxt.com/content/v2/carousel/_info?group={group}&language={lang}"
    headers = NAV_HEADERS.copy()
    headers['contentlanguage'] = lang
    try:
        r = requests.get(url, headers=headers).json()
        for item in r.get('results', []):
            title = item.get('title', 'Unknown')
            cat_id = item.get('name')
            images = item.get('images', [])
            thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
            query = {'action': 'list_content', 'cat_id': cat_id, 'lang': lang, 'start': '1'}
            add_dir(title, query, thumb, isFolder=True)
    except Exception as e: log(f"Group Discovery Error: {str(e)}")
    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(gid, lang, start_index):
    url = f"https://pwaapi.sunnxt.com/content/v3/vods/{gid}/?&orderBy=releaseDate&orderMode=-1&fields=contents,user/currentdata,images,generalInfo,relatedCast,globalServiceName,globalServiceId,publishingHouse&startIndex={start_index}&count=30&contentlang={lang}"
    headers = NAV_HEADERS.copy()
    headers['contentlanguage'] = lang
    try:
        r = requests.get(url, headers=headers).json()
        results = r.get('results', [])
        for item in results:
            g = item.get('generalInfo', {})
            ep_title = g.get('displayTitle', 'Unknown Episode')
            description = g.get('description') or g.get('briefDescription', '')
            images = item.get('images', {}).get('values', [])
            thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
            
            query = {'action': 'play', 'id': item.get('_id'), 'title': ep_title, 'thumb': thumb}
            item_url = f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"
            list_item = xbmcgui.ListItem(label=ep_title)
            list_item.setArt({'thumb': thumb, 'poster': thumb})
            list_item.setProperty('IsPlayable', 'true')
            
            info = list_item.getVideoInfoTag()
            info.setTitle(ep_title)
            info.setPlot(description)
            xbmcplugin.addDirectoryItem(HANDLE, item_url, list_item, isFolder=False)
            
        if len(results) >= 30:
            next_start = int(start_index) + 1
            query = {'action': 'list_episodes', 'gid': gid, 'lang': lang, 'start': str(next_start)}
            add_dir("[COLOR gold]Next Page >>>[/COLOR]", query, isFolder=True)
    except Exception as e: log(f"Episode Listing Error: {str(e)}")
    xbmcplugin.endOfDirectory(HANDLE)

def list_content(cat_id, lang, start_index):
    url = f"https://pwaapi.sunnxt.com/content/v2/carousel/{cat_id}?level=devicemax&startIndex={start_index}&count=24&contentlang={lang}"
    headers = NAV_HEADERS.copy()
    headers['contentlanguage'] = lang
    try:
        r = requests.get(url, headers=headers).json()
        results = r.get('results', [])
        for item in results:
            g = item.get('generalInfo', {})
            title = g.get('title', 'Unknown')
            
            if g.get('type') == 'promotion':
                action_url = g.get('actionURL', '')
                nested_id = action_url.split('/')[-1].split('?')[0] if '/' in action_url else ""
                images = item.get('images', {}).get('values', [])
                thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
                query = {'action': 'list_content', 'cat_id': nested_id, 'lang': lang, 'start': '1'}
                add_dir(f"[COLOR cyan]{title}[/COLOR]", query, thumb, isFolder=True)
            elif item.get('globalServiceId'):
                gid = item.get('globalServiceId')
                images = item.get('images', {}).get('values', [])
                thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
                query = {'action': 'list_episodes', 'gid': gid, 'lang': lang, 'start': '1'}
                add_dir(title, query, thumb, isFolder=True)
            else:
                alt_title = ""
                for alt in g.get('altTitle', []):
                    if alt.get('language') == 'type': alt_title = alt.get('title')
                description = g.get('description') or g.get('briefDescription', '')
                plot = f"{alt_title}\n\n{description}" if alt_title else description
                images = item.get('images', {}).get('values', [])
                thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
                
                query = {'action': 'play', 'id': item.get('_id'), 'title': title, 'thumb': thumb}
                item_url = f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"
                list_item = xbmcgui.ListItem(label=title)
                list_item.setArt({'thumb': thumb, 'poster': thumb})
                list_item.setProperty('IsPlayable', 'true')
                
                info = list_item.getVideoInfoTag()
                info.setTitle(title)
                info.setPlot(plot)
                xbmcplugin.addDirectoryItem(HANDLE, item_url, list_item, isFolder=False)
        
        if len(results) >= 24:
            next_start = int(start_index) + 1
            next_query = {'action': 'list_content', 'cat_id': cat_id, 'lang': lang, 'start': str(next_start)}
            add_dir("[COLOR gold]Next Page >>>[/COLOR]", next_query, isFolder=True)
            
    except Exception as e: log(f"Listing Error: {str(e)}")
    xbmcplugin.endOfDirectory(HANDLE)

# --- 4. THE RESOLVER ---

def play_video(content_id, title):
    log(f"--- RESOLVING VIDEO FOR ID: {content_id} ---")
    
    # --- GET SETTINGS ---
    enable_dv = ADDON.getSetting('enable_dolby_vision') == 'true'
    enable_hdr = ADDON.getSetting('enable_hdr') == 'true'
    
    api_url = f"https://api.sunnxt.com/content/v3/contentDetail/{content_id}?fields=videos,videoInfo,contents,generalInfo,images,publishingHouse,elapsedTime,subtitles&network=wifi"
    
    try:
        r = requests.get(api_url, headers=PLAY_HEADERS, timeout=15)
        resp_json = r.json()
        
        # Log response for debugging
        log(f"ANDROID API RESPONSE: {json.dumps(resp_json)}") 

        if resp_json.get('code') != 200 or not resp_json.get('results'):
            log(f"API Error: {resp_json.get('message', 'Unknown')}")
            xbmcgui.Dialog().notification('Error', 'Content not available', xbmcgui.NOTIFICATION_ERROR)
            return

        result_item = resp_json['results'][0]
        videos_list = result_item.get('videos', {}).get('values', [])
        subs_list = result_item.get('subtitles', {}).get('values', [])
        
        # --- STREAM SELECTION ---
        video_item = None
        
        def get_stream_score(v):
            score = 0
            fmt = v.get('format', '')
            profile = v.get('profile', '').lower()
            
            if 'dash' not in fmt: return -1
            
            # Prefer Native CENC (Standard AWS Streams)
            if 'dash-cenc' in fmt: score += 50
            
            # --- UPDATED: Respect Settings ---
            if '4kdv' in profile:
                if not enable_dv: return -1 # Skip if setting disabled
                score += 50
            elif '4khdr' in profile:
                if not enable_hdr: return -1 # Skip if setting disabled
                score += 40
            elif '4k' in profile: 
                score += 30
            elif 'dolby' in profile or 'atmos' in profile: 
                score += 20
            elif 'high' in profile or 'hd' in profile: 
                score += 10
            
            return score

        videos_list.sort(key=get_stream_score, reverse=True)
        if videos_list and get_stream_score(videos_list[0]) >= 0:
            video_item = videos_list[0]
        
        if not video_item:
            xbmcgui.Dialog().notification('Error', 'No Compatible Stream Found', xbmcgui.NOTIFICATION_ERROR)
            return

        mpd_url = video_item['link']
        license_url = video_item.get('licenseUrl', '') 
        resolution = video_item.get('resolution', '')
        
        # Fallback: Borrow license if the chosen stream happens to be missing one
        if not license_url:
            log("Selected stream missing License. Scanning others...")
            for v in videos_list:
                if v.get('licenseUrl'):
                    license_url = v.get('licenseUrl')
                    log(f"Borrowed License URL from {v.get('cdnType')} stream.")
                    break

        log(f"Selected | CDN: {video_item.get('cdnType')} | Profile: {video_item.get('profile')} | Format: {video_item.get('format')}")

        # --- PLAY ITEM SETUP ---
        play_item = xbmcgui.ListItem(label=title, path=mpd_url)
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')

        # --- CONSTRUCT LICENSE KEY ---
        if license_url:
            token = ""
            if 'token=' in license_url:
                try:
                    token = license_url.split('token=')[1].split('&')[0]
                except:
                    token = license_url.split('token=')[1]
            
            lic_headers = {
                'User-Agent': PLAY_HEADERS['User-Agent'],
                'Content-Type': 'application/octet-stream',
                'nv-authorizations': token
            }
            play_item.setProperty('inputstream.adaptive.license_key', f"{license_url}|{urllib.parse.urlencode(lic_headers)}|R{{SSM}}|")

        # --- STREAM DOWNLOAD HEADERS ---
        # Crucial for AWS/Search results to avoid 403 Forbidden
        stream_headers = {
            'User-Agent': PLAY_HEADERS['User-Agent'],
            'Referer': 'https://www.sunnxt.com/'
        }
        play_item.setProperty('inputstream.adaptive.stream_headers', urllib.parse.urlencode(stream_headers))
        
        # Resolution
        if resolution and 'x' in resolution:
            try:
                w, h = resolution.split('x')
                info_tag = play_item.getVideoInfoTag()
                if hasattr(info_tag, 'setWidth'): info_tag.setWidth(int(w))
                if hasattr(info_tag, 'setHeight'): info_tag.setHeight(int(h))
            except: pass

        # Subtitles
        if subs_list:
            sub_link = next((s['link_sub'] for s in subs_list if 'English' in s.get('language', '')), None)
            if not sub_link and len(subs_list) > 0:
                sub_link = subs_list[0].get('link_sub')
            
            if sub_link:
                if not sub_link.endswith('.srt'): sub_link += '.srt'
                play_item.setSubtitles([sub_link])

        xbmcplugin.setResolvedUrl(HANDLE, True, play_item)

    except Exception as e:
        log(f"Play Crash: {str(e)}")
        xbmcgui.Dialog().notification('Error', 'Playback Failed', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

if __name__ == '__main__':
    try: params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    except: params = {}
    
    action = params.get('action')
    
    if not action: root_menu()
    elif action == 'open_settings': ADDON.openSettings()
    elif action == 'search_menu': search_menu()
    elif action == 'list_search_results': list_search_results(params['query'], params.get('start', '1'))
    elif action == 'list_lang_sections': list_lang_sections(params['lang'])
    elif action == 'list_group': list_group(params['lang'], params['group'])
    elif action == 'list_content': list_content(params['cat_id'], params['lang'], params.get('start', '1'))
    elif action == 'list_episodes': list_episodes(params['gid'], params['lang'], params.get('start', '1'))
    elif action == 'play': play_video(params['id'], params['title'])
