import sys
import urllib.parse
import re
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

# --- 1. CONFIGURATION ---
ADDON = xbmcaddon.Addon()
BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
PAGE_SIZE = 24

EROS_LOGO = "https://erosnow.com/public/images/logo-192_192.png"
EROS_FANART = "https://enwebasset.cdnassets.erosnow.com/production/Ipad_Black_Iphone0eba7ceac20996ad454cfa0fbbd86f33.png"

USER_COOKIE = "device-id=52f2a618-9942-502b-9cc7-655b21145633; _gcl_au=1.1.1809354886.1768248144; _ga=GA1.2.875607771.1768248144; _gid=GA1.2.563854010.1768248144; _fbp=fb.1.1768248143849.27023224195092669; auth_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1dWlkIjoxNzY4MjQ3NTI1MzgsImV4cCI6MTc3NjAyNDE2MX0.fAWE64xkaBcpxdkGsKmECX4ZQpv64GkkYgThPvKb8OM; country_code=AU; _gat_UA-25621672-8=1; _ga_JLWRLHPNV8=GS2.2.s1768248144$o1$g1$t1768251662$j60$l0$h0"

def get_headers(is_private=False):
    headers = {
        'accept': 'application/json, text/plain, */*',
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
    }
    if is_private:
        headers.update({
            'authority': 'pwaproxy.erosnow.com',
            'origin': 'https://erosnow.com',
            'referer': 'https://erosnow.com/',
            'x-country': 'AU',
            'x-device-id': '52f2a618-9942-502b-9cc7-655b21145633',
            'x-platform': 'WEB',
            'cookie': USER_COOKIE
        })
    return headers

# --- 2. CATALOG & NAVIGATION ---

def root_menu():
    add_dir("[COLOR yellow][B]Search ErosNow[/B][/COLOR]", {'action': 'search_input'}, icon=EROS_LOGO, fanart=EROS_FANART)
    langs = [('Malayalam', 'mal'), ('Tamil', 'tam'), ('Telugu', 'tel'), ('Hindi', 'hin'), 
             ('Kannada', 'kan'), ('Marathi', 'mar'), ('Punjabi', 'pun'), ('Bengali', 'ben')]
    for name, slug in langs:
        add_dir(name, {'action': 'list_movies', 'lang': slug}, icon=EROS_LOGO, fanart=EROS_FANART)
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(lang=None, query=None, skip=0):
    """Catalog fetcher optimized for Bingie with robust image handling."""
    if query:
        api_url = "https://pwaproxy.erosnow.com/api/v2/catalog/search"
        params = {'q': query, 'max_result': PAGE_SIZE, 'content_type_id': 1}
        headers = get_headers(is_private=True)
    else:
        api_url = "https://pwaproxy.erosnow.com/api/v2/catalog/movies"
        params = {'start_index': skip, 'max_result': PAGE_SIZE, 'img_quality': 1, 
                  'optimized': 'true', 'language': lang, 'popular': 'true', 'content_type_id': 1}
        headers = get_headers(is_private=False)

    r = requests.get(api_url, params=params, headers=headers).json()
    
    rows = r.get('rows', []) if isinstance(r, dict) else []
    if not rows and isinstance(r, list):
        found = next((item for item in r if 'rows' in item), {})
        rows = found.get('rows', [])
    
    total_content = int(r.get('total', 0)) if isinstance(r, dict) else 0

    for item in rows:
        asset_id = item['asset_id']
        title = item['title']
        
        list_item = xbmcgui.ListItem(label=title)

        # 🖼️ SAFE ARTWORK PARSER
        # Handles cases where images is a list of dicts OR a dict of strings
        images = item.get('images', [])
        poster = ""
        landscape = ""
        logo = ""

        if isinstance(images, list):
            for img in images:
                if isinstance(img, dict):
                    img_type = img.get('type', '').lower()
                    img_url = img.get('url')
                    if img_type == 'poster': poster = img_url
                    elif img_type in ['landscape', 'horizontal']: landscape = img_url
                    elif img_type in ['logo', 'clearlogo']: logo = img_url
        elif isinstance(images, dict):
            # Fallback for search API which uses ID keys (e.g., '96' for poster)
            poster = images.get('96') or images.get('53')
            landscape = images.get('99') or images.get('12')

        list_item.setArt({
            'poster': poster or EROS_LOGO,
            'thumb': landscape or poster or EROS_LOGO,
            'fanart': landscape or EROS_FANART,
            'clearlogo': logo or EROS_LOGO
        })

        list_item.setInfo('video', {
            'title': title, 
            'year': int(item.get('release_year', 0)),
            'plot': item.get('short_description') or item.get('description', ''),
            'studio': 'ErosNow',
            'mediatype': 'movie'
        })

        url = f"{BASE_URL}?action=play&id={asset_id}&title={urllib.parse.quote(title)}"
        list_item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

    if not query and (skip + PAGE_SIZE) < total_content:
        next_skip = skip + PAGE_SIZE
        add_dir(f"[COLOR yellow]Next Page >>>[/COLOR]", 
                {'action': 'list_movies', 'lang': lang, 'skip': next_skip}, 
                icon=EROS_LOGO, fanart=EROS_FANART)

    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)

# --- 3. THE INSTANT PLAYER ---

def play_movie(asset_id, title):
    try:
        detail_url = f"https://pwaproxy.erosnow.com/api/v2/catalog/movie/{asset_id}"
        detail = requests.get(detail_url, headers=get_headers()).json()
        content_id = detail['contents'][0]['content_id']
        
        profile_url = f"https://pwaproxy.erosnow.com/api/v2/catalog/profiles/0.1/{content_id}"
        p_params = {'client_country_code': 'AU', 'platform': '2', 'version': '2', 'quality': 'auto'}
        profile = requests.get(profile_url, params=p_params, headers=get_headers(is_private=True)).json()

        stream_url = None
        for key in ['ADAPTIVE_ALL', 'ADAPTIVE_ALL_CC', 'ADAPTIVE', 'HLS_1200']:
            if 'profiles' in profile and profile['profiles'].get(key):
                stream_url = profile['profiles'][key][0].get('url')
                if stream_url: break
        
        if stream_url:
            play_item = xbmcgui.ListItem(label=title, path=stream_url)
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            xbmcplugin.setResolvedUrl(HANDLE, True, play_item)
    except:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

def add_dir(name, query, icon=None, fanart=None):
    url = f"{BASE_URL}?" + urllib.parse.urlencode(query)
    list_item = xbmcgui.ListItem(label=name)
    if icon: list_item.setArt({'icon': icon, 'thumb': icon})
    if fanart: list_item.setArt({'fanart': fanart})
    xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

if __name__ == '__main__':
    args = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    mode = args.get('action')
    if not mode: root_menu()
    elif mode == 'search_input':
        kb = xbmcgui.Dialog().input('Search ErosNow', type=xbmcgui.INPUT_ALPHANUM)
        if kb: list_movies(query=kb)
    elif mode == 'list_movies':
        list_movies(lang=args.get('lang'), query=args.get('query'), skip=int(args.get('skip', 0)))
    elif mode == 'play': play_movie(args['id'], args.get('title'))