import sys
import urllib.parse
import json
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

# --- 1. CONFIGURATION ---
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])

DEFAULT_BACKDROP = "https://www.sunnxt.com/images/logins_bgimg.jpg"
DEFAULT_ICON = "https://www.sunnxt.com/images/logo/logo.png"

# Headers for Navigation (Browsing Menus) - Uses PWA API
NAV_HEADERS = {
    'accept': '*/*',
    'accept-encoding': 'gzip, deflate, br, zstd',
    'accept-language': 'en',
    'cache-control': 'no-cache',
    'contentlanguage': 'malayalam',
    'cookie': 'sessionid=hzyp3osrklrt7j2kvpcywz8clkx62d6y',
    'origin': 'https://www.sunnxt.com',
    'referer': 'https://www.sunnxt.com/',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'x-myplex-platform': 'browser',
    'x-ucv': '5'
}

# Headers for Playback - Uses New Android API (No Decryption Needed)
PLAY_HEADERS = {
    'Accept-Encoding': 'gzip',
    'Accept-Language': 'en',
    'AppVersion': '200329',
    'clientKey': 'd99d1a8dd9f8da3a5ce7b1c1f28469216dc5c9ee50c948b66941421f5c58e0ab',
    'Connection': 'Keep-Alive',
    'ContentLanguage': 'malayalam',
    'Host': 'api.sunnxt.com',
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; 23116PN5BC Build/PQ3A.190705.01301014)',
    'X-myplex-maturity-level': '',
    'X-myplex-platform': 'android',
    'x-ucv': '5'
}

def log(msg):
    xbmc.log(f"SUNNXT_DEBUG >> {msg}", xbmc.LOGINFO)

# --- 2. NAVIGATION ---

def root_menu():
    languages = ["malayalam", "tamil", "telugu", "kannada", "hindi", "bengali", "marathi", "english"]
    for lang in languages:
        query = {'action': 'list_lang_sections', 'lang': lang}
        add_dir(lang.capitalize(), query, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_lang_sections(lang):
    add_dir("[COLOR yellow]Movies[/COLOR]", {'action': 'list_group', 'lang': lang, 'group': 'portalMovies'}, isFolder=True)
    add_dir("[COLOR cyan]TV Shows[/COLOR]", {'action': 'list_group', 'lang': lang, 'group': 'portalTvShows'}, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_group(lang, group):
    url = f"https://pwaapi.sunnxt.com/content/v2/carousel/_info?group={group}&language={lang}"
    headers = NAV_HEADERS.copy()
    headers['contentlanguage'] = lang
    try:
        r = requests.get(url, headers=headers).json()
        for item in r.get('results', []):
            title = item.get('title', 'Unknown')
            cat_id = item.get('name')
            images = item.get('images', [])
            thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
            query = {'action': 'list_content', 'cat_id': cat_id, 'lang': lang, 'start': '1'}
            add_dir(title, query, thumb, isFolder=True)
    except Exception as e: log(f"Group Discovery Error: {str(e)}")
    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(gid, lang, start_index):
    url = f"https://pwaapi.sunnxt.com/content/v3/vods/{gid}/?&orderBy=releaseDate&orderMode=-1&fields=contents,user/currentdata,images,generalInfo,relatedCast,globalServiceName,globalServiceId,publishingHouse&startIndex={start_index}&count=30&contentlang={lang}"
    headers = NAV_HEADERS.copy()
    headers['contentlanguage'] = lang
    try:
        r = requests.get(url, headers=headers).json()
        results = r.get('results', [])
        for item in results:
            g = item.get('generalInfo', {})
            ep_title = g.get('displayTitle', 'Unknown Episode')
            plot = g.get('description', '')
            images = item.get('images', {}).get('values', [])
            thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
            
            query = {'action': 'play', 'id': item.get('_id'), 'title': ep_title, 'thumb': thumb}
            item_url = f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"
            list_item = xbmcgui.ListItem(label=ep_title)
            list_item.setArt({'thumb': thumb, 'poster': thumb})
            list_item.setProperty('IsPlayable', 'true')
            
            info = list_item.getVideoInfoTag()
            info.setTitle(ep_title)
            info.setPlot(plot)
            xbmcplugin.addDirectoryItem(HANDLE, item_url, list_item, isFolder=False)
            
        if len(results) >= 30:
            next_start = int(start_index) + 1
            query = {'action': 'list_episodes', 'gid': gid, 'lang': lang, 'start': str(next_start)}
            add_dir("[COLOR gold]Next Page >>>[/COLOR]", query, isFolder=True)
    except Exception as e: log(f"Episode Listing Error: {str(e)}")
    xbmcplugin.endOfDirectory(HANDLE)

def list_content(cat_id, lang, start_index):
    url = f"https://pwaapi.sunnxt.com/content/v2/carousel/{cat_id}?level=devicemax&startIndex={start_index}&count=24&contentlang={lang}"
    headers = NAV_HEADERS.copy()
    headers['contentlanguage'] = lang
    try:
        r = requests.get(url, headers=headers).json()
        results = r.get('results', [])
        for item in results:
            g = item.get('generalInfo', {})
            title = g.get('title', 'Unknown')
            
            if g.get('type') == 'promotion':
                action_url = g.get('actionURL', '')
                nested_id = action_url.split('/')[-1].split('?')[0] if '/' in action_url else ""
                images = item.get('images', {}).get('values', [])
                thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
                query = {'action': 'list_content', 'cat_id': nested_id, 'lang': lang, 'start': '1'}
                add_dir(f"[COLOR cyan]{title}[/COLOR]", query, thumb, isFolder=True)
            elif item.get('globalServiceId'):
                gid = item.get('globalServiceId')
                images = item.get('images', {}).get('values', [])
                thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
                query = {'action': 'list_episodes', 'gid': gid, 'lang': lang, 'start': '1'}
                add_dir(title, query, thumb, isFolder=True)
            else:
                alt_title = ""
                for alt in g.get('altTitle', []):
                    if alt.get('language') == 'type': alt_title = alt.get('title')
                plot = f"{alt_title}\n\n{g.get('description', '')}" if alt_title else g.get('description', '')
                images = item.get('images', {}).get('values', [])
                thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
                
                query = {'action': 'play', 'id': item.get('_id'), 'title': title, 'thumb': thumb}
                item_url = f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"
                list_item = xbmcgui.ListItem(label=title)
                list_item.setArt({'thumb': thumb, 'poster': thumb})
                list_item.setProperty('IsPlayable', 'true')
                
                info = list_item.getVideoInfoTag()
                info.setTitle(title)
                info.setPlot(plot)
                xbmcplugin.addDirectoryItem(HANDLE, item_url, list_item, isFolder=False)
        
        if len(results) >= 24:
            next_start = int(start_index) + 1
            next_query = {'action': 'list_content', 'cat_id': cat_id, 'lang': lang, 'start': str(next_start)}
            add_dir("[COLOR gold]Next Page >>>[/COLOR]", next_query, isFolder=True)
            
    except Exception as e: log(f"Listing Error: {str(e)}")
    xbmcplugin.endOfDirectory(HANDLE)

# --- 3. THE RESOLVER (NEW V3 ANDROID API) ---

def play_video(content_id, title):
    log(f"--- RESOLVING VIDEO FOR ID: {content_id} ---")
    
    # New V3 Endpoint using Android Client params
    api_url = f"https://api.sunnxt.com/content/v3/contentDetail/{content_id}?fields=videos,videoInfo,contents,generalInfo,images,publishingHouse,elapsedTime,subtitles&network=wifi"
    
    try:
        # 1. Request Data (No Decryption Required)
        r = requests.get(api_url, headers=PLAY_HEADERS, timeout=15)
        resp_json = r.json()
        
        # Validation
        if resp_json.get('code') != 200 or not resp_json.get('results'):
            log(f"API Error: {resp_json.get('message', 'Unknown')}")
            xbmcgui.Dialog().notification('Error', 'Content not available', xbmcgui.NOTIFICATION_ERROR)
            return

        result_item = resp_json['results'][0]
        videos_list = result_item.get('videos', {}).get('values', [])
        
        # 2. Select Stream (Strategy: Find 'dash-cenc' -> Prioritize 4K/Dolby)
        video_item = None
        
        # Helper to score streams: 4k_dolby(3) > dolby(2) > High(1)
        def get_stream_score(v):
            score = 0
            # We enforce dash-cenc for Widevine
            if v.get('format') != 'dash-cenc':
                return -1 
            
            profile = v.get('profile', '').lower()
            if '4k' in profile: score += 3
            elif 'dolby' in profile: score += 2
            elif 'high' in profile: score += 1
            return score

        # Sort streams by quality score descending
        videos_list.sort(key=get_stream_score, reverse=True)
        
        # Pick the best valid stream
        if videos_list and get_stream_score(videos_list[0]) >= 0:
            video_item = videos_list[0]
        
        # Fallback: If no strict dash-cenc found, try any generic dash
        if not video_item:
            log("Warning: No optimal dash-cenc stream found. Trying fallback.")
            video_item = next((v for v in videos_list if 'dash' in v.get('format', '')), None)

        if not video_item:
            xbmcgui.Dialog().notification('Error', 'No Compatible Stream Found', xbmcgui.NOTIFICATION_ERROR)
            return

        mpd_url = video_item['link']
        license_url = video_item.get('licenseUrl', '')
        resolution = video_item.get('resolution', '')
        
        log(f"Selected Profile: {video_item.get('profile')} | Format: {video_item.get('format')} | URL: {mpd_url}")

        # 3. Construct License Headers (Widevine)
        # Extract token from URL for the specific 'nv-authorizations' header SunNXT uses
        token = ""
        if 'token=' in license_url:
            token = license_url.split('token=')[1]
        
        lic_headers = {
            'User-Agent': PLAY_HEADERS['User-Agent'],
            'Content-Type': 'application/octet-stream',
            'nv-authorizations': token  # Critical for SunNXT/Nagra
        }
        
        header_str = urllib.parse.urlencode(lic_headers)
        # Append headers and response expectation to license URL
        license_key = f"{license_url}|{header_str}|R{{SSM}}|"
        
        # 4. Build Player Item
        play_item = xbmcgui.ListItem(label=title, path=mpd_url)
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
        play_item.setProperty('inputstream.adaptive.license_key', license_key)
        
        # Set Resolution metadata if available
        if resolution and 'x' in resolution:
            try:
                w, h = resolution.split('x')
                play_item.setInfo('video', {'width': w, 'height': h})
            except: pass

        # 5. Add Subtitles (with .srt appending logic)
        subs_list = result_item.get('subtitles', {}).get('values', [])
        if subs_list:
            # Try to find English first
            sub_link = next((s['link_sub'] for s in subs_list if 'English' in s.get('language', '')), None)
            # Fallback to first available if no English
            if not sub_link and len(subs_list) > 0:
                sub_link = subs_list[0].get('link_sub')
            
            if sub_link:
                # FIX: Append .srt if not present
                if not sub_link.endswith('.srt'):
                    sub_link += '.srt'
                    
                play_item.setSubtitles([sub_link])

        xbmcplugin.setResolvedUrl(HANDLE, True, play_item)

    except Exception as e:
        log(f"Play Crash: {str(e)}")
        xbmcgui.Dialog().notification('Error', 'Playback Failed', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

def add_dir(name, query, thumb=None, isFolder=True):
    url = f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"
    item = xbmcgui.ListItem(label=name)
    img_thumb = thumb if thumb else DEFAULT_ICON
    img_fanart = thumb if thumb else DEFAULT_BACKDROP
    item.setArt({
        'thumb': img_thumb,
        'icon': img_thumb,
        'fanart': img_fanart
    })
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=isFolder)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    if not action: root_menu()
    elif action == 'list_lang_sections': list_lang_sections(params['lang'])
    elif action == 'list_group': list_group(params['lang'], params['group'])
    elif action == 'list_content': list_content(params['cat_id'], params['lang'], params.get('start', '1'))
    elif action == 'list_episodes': list_episodes(params['gid'], params['lang'], params.get('start', '1'))
    elif action == 'play': play_video(params['id'], params['title'])
