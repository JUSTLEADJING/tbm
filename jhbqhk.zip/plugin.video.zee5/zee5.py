import sys
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
from urllib.parse import urlencode, parse_qsl, quote

# Addon setup
ADDON = xbmcaddon.Addon()
try:
    HANDLE = int(sys.argv[1])
except:
    HANDLE = -1
BASE_URL = sys.argv[0]
USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"

def log(msg):
    """Helper to print to kodi.log"""
    xbmc.log(f"ZEE5-DEBUG: {msg}", xbmc.LOGINFO)

class ZeeGlobalAPI:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": USER_AGENT,
            "Referer": "https://www.zee5.com/",
            "Accept": "application/json",
            "sec-ch-ua-platform": '"macOS"'
        })

    def get_movies(self, page=1, lang="ml"):
        url = "https://gwapi.zee5.com/v1/movie"
        params = {
            "page": page, "page_size": 20, "country": "IN",
            "asset_subtype": "movie", "translation": "en",
            "sort_by_field": "release_date", "sort_order": "desc",
            "version": "2", "languages": lang
        }
        try:
            r = self.session.get(url, params=params)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            log(f"Get Movies Error: {e}")
            return {}

    def get_playback(self, content_id):
        url = "https://spapi.zee5.com/singlePlayback/v2/getDetails/secure"
        params = {
            "content_id": content_id, "device_id": "7da4db04-bd37-4efd-a229-8cce6dab7f5d",
            "platform_name": "desktop_web", "translation": "en", "user_language": "ml,ta,kn",
            "country": "IN", "state": "WB", "app_version": "5.1.7", "user_type": "premium",
            "check_parental_control": "false", "gender": "Male", "age_group": "18-24",
            "uid": "575ca7ea-dcb2-42b4-9202-198f67585f52", "ppid": "7da4db04-bd37-4efd-a229-8cce6dab7f5d",
            "version": "15"
        }
        headers = {
            "accept": "application/json",
            "authorization": "bearer eyJraWQiOiJkZjViZjBjOC02YTAxLTQ0MWEtOGY2MS0yMDllMjE2MGU4MTUiLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI1NzVDQTdFQS1EQ0IyLTQyQjQtOTIwMi0xOThGNjc1ODVGNTIiLCJkZXZpY2VfaWQiOiI3ZGE0ZGIwNC1iZDM3LTRlZmQtYTIyOS04Y2NlNmRhYjdmNWQiLCJhbXIiOlsiZGVsZWdhdGlvbiJdLCJ0YXJnZXRlZF9pZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly91c2VyYXBpLnplZTUuY29tIiwidmVyc2lvbiI6MTEsImNsaWVudF9pZCI6InJlZnJlc2hfdG9rZW4iLCJhdWQiOlsidXNlcmFwaSIsInN1YnNjcmlwdGlvbmFwaSIsInByb2ZpbGVhcGkiLCJnYW1lLXBsYXkiXSwidXNlcl90eXBlIjoiUmVnaXN0ZXJlZCIsIm5iZiI6MTc2ODk3OTc0OSwidXNlcl9pZCI6IjU3NWNhN2VhLWRjYjItNDJiNC05MjAyLTE5OGY2NzU4NWY1MiIsInNjb3BlIjpbInVzZXJhcGkiLCJzdWJzY3JpcHRpb25hcGkiLCJwcm9maWxlYXBpIl0sInNlc3Npb25fdHlwZSI6IkdFTkVSQUwiLCJleHAiOjE3NjkzMjUzNDksImlhdCI6MTc2ODk3OTc0OSwidGVuYW50IjoiemVlNSIsImp0aSI6IjdmNzg1NDgzLWYwNTQtNDhhZC1hYTQ3LTU2ODkyZjJlMGNiOSJ9.AJMw7iGgUfcpMLtt1VCPk2M3IEpo4oChVupIfhkPXIuX1ddvZguge6vxgt7l8vMTakvjlmu2a1_Wvq9xo-S-PZv7rx8hmzDVwR1mIaOIwV3r5Dm5FYme6aWRcH__m2NZ-LxOegYuDGgaWbAINF5pZQ8qYI1qGga0PuKiNvv1VOU6bCLhBF24OG0V1JkGkVZIzTvrjrukVRr_y7EidLDpEHJ2IP8H2eQolEeUdzRi9hkuGoGvsLL5W0gVt3ont4DiGZkMa8aNOLd4dIOwVfapWE87DkvKvXV9WsyZjPEKpN4a7_QGobdAZMp4FuHbNjAskrXR_MEBUWH76FvdBsJB6w",
            "content-type": "application/json"
        }
        payload = {
            "x-access-token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwbGF0Zm9ybV9jb2RlIjoiV2ViQCQhdDM4NzEyIiwiaXNzdWVkQXQiOiIyMDI2LTAxLTIwVDIzOjUwOjA5LjcxN1oiLCJwcm9kdWN0X2NvZGUiOiJ6ZWU1QDk3NSIsInR0bCI6ODY0MDAwMDAsImlhdCI6MTc2ODk1MzAwOX0.qWMgvBvPgmw71Xf8u5pU6GSFQPIWGafEizbXEGJ_jCQ",
            "Authorization": headers["authorization"],
            "x-dd-token": "eyJzY2hlbWFfdmVyc2lvbiI6IjEiLCJvc19uYW1lIjoiTi9BIiwib3NfdmVyc2lvbiI6Ik4vQSIsInBsYXRmb3JtX25hbWUiOiJDaHJvbWUiLCJwbGF0Zm9ybV92ZXJzaW9uIjoiMTA0IiwiZGV2aWNlX25hbWUiOiIiLCJhcHBfbmFtZSI6IldlYiIsImFwcF92ZXJzaW9uIjoiMi41Mi4zMSIsInBsYXllcl9jYXBhYmlsaXRpZXMiOnsiYXVkaW9fY2hhbm5lbCI6WyJTVEVSRU8iXSwidmlkZW9fY29kZWMiOlsiSDI2NCJdLCJjb250YWluZXIiOlsiTVA0IiwiVFMiXSwicGFja2FnZSI6WyJEQVNIIiwiSExTIl0sInJlc29sdXRpb24iOlsiMjQwcCIsIlNEIiwiSEQiLCJGSEQiXSwiZHluYW1pY19yYW5nZSI6WyJTRFIiXX0sInNlY3VyaXR5X2NhcGFiaWxpdGllcyI6eyJlbmNyeXB0aW9uIjpbIldJREVWSU5FX0FFU19DVFIiXSwid2lkZXZpbmVfc2VjdXJpdHlfbGV2ZWwiOlsiTDMiXSwiaGRjcF92ZXJzaW9uIjpbIkhEQ1BfVjEiLCJIRENQX1YyIiwiSERDUF9WMl8xIiwiSERDUF9WMl8yIl19fQ=="
        }
        try:
            r = self.session.post(url, params=params, headers=headers, json=payload)
            return r.json()
        except:
            return None

api = ZeeGlobalAPI()

def list_malayalam_movies(page):
    """Hybrid metadata approach to ensure descriptions show in all skins."""
    xbmcplugin.setContent(HANDLE, 'movies')
    data = api.get_movies(page=page)
    items = data.get('items', [])
    
    if not items:
        xbmcgui.Dialog().notification('Zee5', 'No items found', xbmcgui.NOTIFICATION_INFO)
        return

    for item in items:
        title = item.get('title', 'Unknown')
        cid = item.get('id')
        plot = item.get('description', 'No description available.')
        duration = int(item.get('duration', 0))
        rating = float(item.get('rating', 0))
        year = int(item.get('release_date', '0000')[:4])
        mpaa = item.get('age_rating_new', '')
        # Clean actors list
        actors = [a.split(':')[0] for a in item.get('actors', [])]

        li = xbmcgui.ListItem(label=title)
        
        # 1. LEGACY SYSTEM (For the plot box in your screenshot)
        li.setInfo('video', {
            'title': title,
            'plot': plot,
            'tagline': plot, # Some skins use tagline for the sidebox
            'mediatype': 'movie',
            'duration': duration,
            'rating': rating,
            'year': year,
            'mpaa': mpaa,
            'cast': actors
        })

        # 2. MODERN SYSTEM (For technical info bars)
        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setPlot(plot)
        info_tag.setMediaType('movie')
        info_tag.setDuration(duration)
        info_tag.setRating(rating)
        info_tag.setYear(year)
        info_tag.setMpaa(mpaa)
        if actors:
            info_tag.setCast([xbmcgui.InfoTagVideoCast(a) for a in actors])

        # Artwork Logic
        cover_hash = item.get('cover_image', '').replace('.jpg', '')
        poster = f"https://akamaividz2.zee5.com/image/upload/resources/{cid}/portrait/{cover_hash}.jpg"
        list_hash = item.get('list_image', '').replace('.jpg', '')
        fanart = f"https://akamaividz2.zee5.com/image/upload/resources/{cid}/list/{list_hash}.jpg"
        
        li.setArt({'thumb': poster, 'poster': poster, 'fanart': fanart})
        
        # Playable status - keep isFolder=False for working playback
        li.setProperty('IsPlayable', 'true')
        url = f"{BASE_URL}?action=play&id={cid}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    if len(items) >= 20:
        next_url = f"{BASE_URL}?action=list&page={int(page) + 1}"
        xbmcplugin.addDirectoryItem(HANDLE, next_url, xbmcgui.ListItem("Next Page >>"), True)
    
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(content_id):
    """Restored working playback logic with your original headers."""
    data = api.get_playback(content_id)
    play_item = xbmcgui.ListItem()

    if not data:
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=play_item)
        return
    
    asset_details = data.get('assetDetails', {})
    key_os = data.get('keyOsDetails', {})
    video_url = asset_details.get('video_url', {}).get('mpd') or key_os.get('hls_token')

    if video_url:
        # Working Header Extraction
        cookies = api.session.cookies.get_dict()
        cookie_str = '; '.join([f'{k}={v}' for k, v in cookies.items()])
        header_params = {'User-Agent': USER_AGENT, 'Referer': 'https://www.zee5.com/', 'Origin': 'https://www.zee5.com'}
        if cookie_str: header_params['Cookie'] = cookie_str
        header_string = '&'.join([f'{k}={quote(v)}' for k, v in header_params.items()])

        play_item.setPath(f"{video_url}|{header_string}")
        
        if 'sdrm' in key_os:
            lic_url = "https://spapi.zee5.com/widevine/getLicense"
            lic_hdr = f"Content-Type=application/octet-stream&customdata={key_os.get('sdrm')}&nl={key_os.get('nl')}"
            license_key = f"{lic_url}|{lic_hdr}|R{{SSM}}|"
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
            play_item.setProperty('inputstream.adaptive.license_key', license_key)
        
        play_item.setProperty('inputstream.adaptive.stream_headers', header_string)
        play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd' if '.mpd' in video_url else 'hls')
        play_item.setMimeType('application/dash+xml' if '.mpd' in video_url else 'application/vnd.apple.mpegurl')

        # Subtitles
        subs = asset_details.get('subtitle_url', [])
        if subs: play_item.setSubtitles([subs[0].get('url')])

        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)
    else:
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=play_item)

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        list_malayalam_movies(1)
    elif params.get('action') == 'list':
        list_malayalam_movies(params.get('page', 1))
    elif params.get('action') == 'play':
        play_video(params.get('id'))

if __name__ == '__main__':
    router(sys.argv[2][1:])