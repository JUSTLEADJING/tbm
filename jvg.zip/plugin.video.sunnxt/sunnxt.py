import sys
import urllib.parse
import json
import base64
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from Cryptodome.Cipher import AES

# --- 1. CONFIGURATION ---
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
APP_SECRET = "A3s68aORSgHs$71P"
AES_IV = b'\x00' * 16

DEFAULT_BACKDROP = "https://www.sunnxt.com/images/logins_bgimg.jpg"
DEFAULT_ICON = "https://www.sunnxt.com/images/logo/logo.png"

BASE_HEADERS = {
    'accept': '*/*',
    'accept-encoding': 'gzip, deflate, br, zstd',
    'accept-language': 'en',
    'cache-control': 'no-cache',
    'contentlanguage': 'malayalam',
    'cookie': '_tt_enable_cookie=1; _ttp=01KFRCJNPYKCCVT2A2BJAGHWRF_.tt.1; _fbp=fb.1.1769271288692.691124948680980355; WZRK_G=b248bfcdc544401f8f3d62197b3f970c; selected_language=malayalam; language_selected=true; sessionid=n6m56dh8vg4nsmwrgt3ftztsv96wptfh; afUserId=daeacdaf-b907-4b95-9407-c5bdd17af11a-p; AF_SYNC=1769271292867; _gcl_au=1.1.681985411.1769271286.721467727.1769271296.1769271296; _gid=GA1.2.327746359.1769271334; _ga=GA1.1.1176210656.1769271286; maturityRestrictions=; _ga_M4Z38WW7QV=GS2.1.s1769271286$o1$g1$t1769271593$j60$l0$h1852542674; WZRK_S_WW6-54K-855Z=%7B%22p%22%3A8%2C%22s%22%3A1769271289%2C%22t%22%3A1769271595%7D; ttcsid=1769271285487::ZCKhFv8F_VZ6WFnu_Z30.1.1769271687984.0; ttcsid_CFN0QG3C77UCCRP9FAKG=1769271285484::d8FUMWHkDfAQv__d4ZQf.1.1769271687984.1',
    'origin': 'https://www.sunnxt.com',
    'pragma': 'no-cache',
    'priority': 'u=1, i',
    'referer': 'https://www.sunnxt.com/',
    'sec-ch-ua': '"Not(A:Brand";v="8", "Chromium";v="144", "Google Chrome";v="144"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"macOS"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'x-myplex-maturity-level': '',
    'x-myplex-platform': 'browser',
    'x-ucv': '5'
}

def log(msg):
    xbmc.log(f"SUNNXT_DEBUG >> {msg}", xbmc.LOGINFO)

def decrypt_data(encrypted_base64):
    try:
        key = APP_SECRET.encode('utf-8')
        enc_data = base64.b64decode(encrypted_base64.strip())
        cipher = AES.new(key, AES.MODE_CBC, AES_IV)
        decrypted = cipher.decrypt(enc_data)
        padding_len = decrypted[-1]
        decrypted = decrypted[:-padding_len]
        return json.loads(decrypted.decode('utf-8'))
    except Exception as e:
        log(f"Decryption Failure: {str(e)}")
        return None

# --- 2. NAVIGATION ---

def root_menu():
    languages = ["malayalam", "tamil", "telugu", "kannada", "hindi", "bengali", "marathi", "english"]
    for lang in languages:
        query = {'action': 'list_lang_sections', 'lang': lang}
        add_dir(lang.capitalize(), query, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_lang_sections(lang):
    add_dir("[COLOR yellow]Movies[/COLOR]", {'action': 'list_group', 'lang': lang, 'group': 'portalMovies'}, isFolder=True)
    add_dir("[COLOR cyan]TV Shows[/COLOR]", {'action': 'list_group', 'lang': lang, 'group': 'portalTvShows'}, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_group(lang, group):
    url = f"https://pwaapi.sunnxt.com/content/v2/carousel/_info?group={group}&language={lang}"
    headers = BASE_HEADERS.copy()
    headers['contentlanguage'] = lang
    try:
        r = requests.get(url, headers=headers).json()
        for item in r.get('results', []):
            title = item.get('title', 'Unknown')
            cat_id = item.get('name')
            images = item.get('images', [])
            thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
            query = {'action': 'list_content', 'cat_id': cat_id, 'lang': lang, 'start': '1'}
            add_dir(title, query, thumb, isFolder=True)
    except Exception as e: log(f"Group Discovery Error: {str(e)}")
    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(gid, lang, start_index):
    url = f"https://pwaapi.sunnxt.com/content/v3/vods/{gid}/?&orderBy=releaseDate&orderMode=-1&fields=contents,user/currentdata,images,generalInfo,relatedCast,globalServiceName,globalServiceId,publishingHouse&startIndex={start_index}&count=30&contentlang={lang}"
    headers = BASE_HEADERS.copy()
    headers['contentlanguage'] = lang
    try:
        r = requests.get(url, headers=headers).json()
        results = r.get('results', [])
        for item in results:
            g = item.get('generalInfo', {})
            ep_title = g.get('displayTitle', 'Unknown Episode')
            plot = g.get('description', '')
            images = item.get('images', {}).get('values', [])
            thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
            
            query = {'action': 'play', 'id': item.get('_id'), 'title': ep_title, 'thumb': thumb}
            item_url = f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"
            list_item = xbmcgui.ListItem(label=ep_title)
            list_item.setArt({'thumb': thumb, 'poster': thumb})
            list_item.setProperty('IsPlayable', 'true')
            
            info = list_item.getVideoInfoTag()
            info.setTitle(ep_title)
            info.setPlot(plot)
            xbmcplugin.addDirectoryItem(HANDLE, item_url, list_item, isFolder=False)
            
        if len(results) >= 30:
            next_start = int(start_index) + 1
            query = {'action': 'list_episodes', 'gid': gid, 'lang': lang, 'start': str(next_start)}
            add_dir("[COLOR gold]Next Page >>>[/COLOR]", query, isFolder=True)
    except Exception as e: log(f"Episode Listing Error: {str(e)}")
    xbmcplugin.endOfDirectory(HANDLE)

def list_content(cat_id, lang, start_index):
    url = f"https://pwaapi.sunnxt.com/content/v2/carousel/{cat_id}?level=devicemax&startIndex={start_index}&count=24&contentlang={lang}"
    headers = BASE_HEADERS.copy()
    headers['contentlanguage'] = lang
    try:
        r = requests.get(url, headers=headers).json()
        results = r.get('results', [])
        for item in results:
            g = item.get('generalInfo', {})
            title = g.get('title', 'Unknown')
            
            if g.get('type') == 'promotion':
                action_url = g.get('actionURL', '')
                nested_id = action_url.split('/')[-1].split('?')[0] if '/' in action_url else ""
                images = item.get('images', {}).get('values', [])
                thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
                query = {'action': 'list_content', 'cat_id': nested_id, 'lang': lang, 'start': '1'}
                add_dir(f"[COLOR cyan]{title}[/COLOR]", query, thumb, isFolder=True)
            elif item.get('globalServiceId'):
                gid = item.get('globalServiceId')
                images = item.get('images', {}).get('values', [])
                thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
                query = {'action': 'list_episodes', 'gid': gid, 'lang': lang, 'start': '1'}
                add_dir(title, query, thumb, isFolder=True)
            else:
                alt_title = ""
                for alt in g.get('altTitle', []):
                    if alt.get('language') == 'type': alt_title = alt.get('title')
                plot = f"{alt_title}\n\n{g.get('description', '')}" if alt_title else g.get('description', '')
                images = item.get('images', {}).get('values', [])
                thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
                
                query = {'action': 'play', 'id': item.get('_id'), 'title': title, 'thumb': thumb}
                item_url = f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"
                list_item = xbmcgui.ListItem(label=title)
                list_item.setArt({'thumb': thumb, 'poster': thumb})
                list_item.setProperty('IsPlayable', 'true')
                
                info = list_item.getVideoInfoTag()
                info.setTitle(title)
                info.setPlot(plot)
                xbmcplugin.addDirectoryItem(HANDLE, item_url, list_item, isFolder=False)
        
        if len(results) >= 24:
            next_start = int(start_index) + 1
            next_query = {'action': 'list_content', 'cat_id': cat_id, 'lang': lang, 'start': str(next_start)}
            add_dir("[COLOR gold]Next Page >>>[/COLOR]", next_query, isFolder=True)
            
    except Exception as e: log(f"Listing Error: {str(e)}")
    xbmcplugin.endOfDirectory(HANDLE)

# --- 3. THE RESOLVER ---

def play_video(content_id, title):
    log(f"--- RESOLVING DRM FOR ID: {content_id} ---")
    api_url = f"https://www.sunnxt.com/next/api/media/{content_id}?playbackCounter=1&fields=videos,generalInfo&licenseType=false"
    try:
        r = requests.get(api_url, headers=BASE_HEADERS, timeout=10)
        data = decrypt_data(r.json().get('response', ''))
        
        videos_list = data['results'][0]['videos']['values']
        
        # --- CRITICAL FIX: SELECT DASH-CENC STREAM ---
        video_item = None
        for v in videos_list:
            # We specifically want 'dash-cenc' for Widevine support
            if v.get('format') == 'dash-cenc':
                video_item = v
                break
        
        # Fallback if dash-cenc isn't explicit found (rare, but good safety)
        if not video_item:
            log("Warning: 'dash-cenc' not found, searching for generic 'dash'")
            for v in videos_list:
                if 'dash' in v.get('format', ''):
                    video_item = v
                    break
        
        if not video_item:
            xbmcgui.Dialog().notification('Error', 'No Compatible Stream Found', xbmcgui.NOTIFICATION_ERROR)
            return

        mpd_url = video_item['link']
        license_url = video_item.get('licenseUrl', '')
        
        log(f"Selected Format: {video_item.get('format')} | URL: {mpd_url}")

        # Extract token from URL for license headers
        token = ""
        if 'token=' in license_url:
            token = license_url.split('token=')[1]
        
        lic_headers = {
            'User-Agent': BASE_HEADERS['user-agent'],
            'Cookie': BASE_HEADERS['cookie'],
            'Content-Type': 'application/octet-stream',
            'Referer': 'https://www.sunnxt.com/',
            'Origin': 'https://www.sunnxt.com',
            'nv-authorizations': token 
        }
        
        header_str = urllib.parse.urlencode(lic_headers)
        license_key = f"{license_url}|{header_str}|R{{SSM}}|"
        
        play_item = xbmcgui.ListItem(label=title, path=mpd_url)
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
        play_item.setProperty('inputstream.adaptive.license_key', license_key)
        play_item.setProperty('inputstream.adaptive.max_video_resolution', '1080')
        
        xbmcplugin.setResolvedUrl(HANDLE, True, play_item)
    except Exception as e:
        log(f"Play Crash: {str(e)}")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

def add_dir(name, query, thumb=None, isFolder=True):
    url = f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"
    item = xbmcgui.ListItem(label=name)
    img_thumb = thumb if thumb else DEFAULT_ICON
    img_fanart = thumb if thumb else DEFAULT_BACKDROP
    item.setArt({
        'thumb': img_thumb,
        'icon': img_thumb,
        'fanart': img_fanart
    })
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=isFolder)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    if not action: root_menu()
    elif action == 'list_lang_sections': list_lang_sections(params['lang'])
    elif action == 'list_group': list_group(params['lang'], params['group'])
    elif action == 'list_content': list_content(params['cat_id'], params['lang'], params.get('start', '1'))
    elif action == 'list_episodes': list_episodes(params['gid'], params['lang'], params.get('start', '1'))
    elif action == 'play': play_video(params['id'], params['title'])