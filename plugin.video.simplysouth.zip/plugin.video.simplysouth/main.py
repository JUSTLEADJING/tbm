import sys
import urllib.parse
import re
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

# --- 1. CONFIGURATION ---
ADDON = xbmcaddon.Addon()
BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
TMDB_API_KEY = "41c349f01435bc2440e53ffd696a074b" 
AUTH_TOKEN = "1e793998500e2183849920a1987b7a16"
USER_ID = "7989896"

# UI Assets - High Res
SS_LOGO = "https://m.media-amazon.com/images/I/21M0DCO2QVL.png"
SS_FANART = "https://m.media-amazon.com/images/I/31cH-rlAmJL.png"

GENRES = ["Action", "Drama", "Comedy", "Horror", "Thriller", "Crime", "Mystery", "Sci-fi", "Adventure", "Music", "Romance", "Sports", "Fantasy", "Animation", "Family", "Biography", "Social"]

USER_COOKIE = '_scid=uryDzSWbbkoCDEsLQ6ZTPcXBT03u1aKI; _pin_unauth=dWlkPU5UZzJNMlkzT1RZdE1EZ3hZeTAwWW1KakxXRTRNMk10WlRJelptTmlPV1JpTm1NeA; _ga=GA1.1.289607742.1755501622; Language=en; FBRLH_state=75ed313ec4cfd719af265495e09cd485; _gcl_au=1.1.1937118400.1768233106; _fbp=fb.1.1768233105647.148230036422751380; PHPSESSID=3onb5q305vckqhkp4ndkjrdkb8; is_ppv=1;'

def get_all_headers(referer='https://simplysouth.tv/'):
    return {
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
        'cookie': USER_COOKIE,
        'referer': referer
    }

# --- 2. HELPERS ---

def clean_title(title):
    return re.sub(r'\s*(?:Telugu|Tamil|Malayalam|Kannada|4K|Dolby Atmos|Atmos|HD|UHD)\s*', '', title, flags=re.IGNORECASE).strip()

def get_tmdb_meta(title, year):
    """Fetches high-res art and ratings from TMDB."""
    try:
        search_url = f"https://api.themoviedb.org/3/search/movie?api_key={TMDB_API_KEY}&query={urllib.parse.quote(title)}&year={year}"
        res = requests.get(search_url).json()
        if res.get('results'):
            movie = res['results'][0]
            return {
                'poster': f"https://image.tmdb.org/t/p/w500{movie.get('poster_path')}",
                'fanart': f"https://image.tmdb.org/t/p/original{movie.get('backdrop_path')}",
                'rating': movie.get('vote_average'),
                'plot': movie.get('overview'),
                'logo': f"https://image.tmdb.org/t/p/original{movie.get('poster_path')}" # Proxy for logo if needed
            }
    except: pass
    return None

# --- 3. MENU NAVIGATION ---

def root_menu():
    add_dir("[COLOR yellow][B]Search Movies[/B][/COLOR]", {'action': 'search_input'}, icon=SS_LOGO, fanart=SS_FANART)
    for lang in ['Tamil', 'Malayalam', 'Telugu', 'Kannada']:
        add_dir(lang, {'action': 'list_genres', 'lang': lang}, icon=SS_LOGO, fanart=SS_FANART)
    xbmcplugin.endOfDirectory(HANDLE)

def list_genres(lang):
    for genre in GENRES:
        add_dir(genre, {'action': 'list_movies', 'lang': lang, 'genre': genre, 'offset': 1}, icon=SS_LOGO, fanart=SS_FANART)
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(lang=None, genre=None, query=None, offset=1):
    """Catalog and Search handler optimized for Bingie widgets."""
    if query:
        api_url = "https://simplysouth.tv/rest/searchData"
        params = {'authToken': AUTH_TOKEN, 'q': query, 'user_id': USER_ID, 'limit': 30, 'less_data': 1}
    else:
        api_url = "https://simplysouth.tv/rest/GetFilteredContent"
        params = {'authToken': AUTH_TOKEN, 'category': 'movie', 'genre': genre, 'language': lang, 'limit': 16, 'offset': offset, 'sort': 'rating', 'less_data': 1}
    
    data = requests.get(api_url, params=params, headers=get_all_headers()).json()
    items = data.get('search') if query else data.get('lists', [])
    
    if items:
        for item in items:
            if query and item.get('is_playlist') == "1": continue
            orig_title = item['title']
            display_title = clean_title(orig_title)
            year = item.get('release_date', '')[:4]
            slug = item.get('c_permalink') if not query else item.get('permalink', '').split('/')[-1]
            
            list_item = xbmcgui.ListItem(label=display_title)
            
            # 🖼️ BINGIE ARTWORK
            # Use banner as 'thumb' for horizontal rows, poster for vertical rows
            poster = item.get('poster')
            banner = item.get('content_banner', poster)
            
            list_item.setArt({
                'poster': poster,
                'thumb': banner,      # Horizontal Netflix row
                'fanart': banner,     # Background
                'clearlogo': SS_LOGO  # Branding overlay
            })

            # ℹ️ BINGIE METADATA
            info = {
                'title': display_title,
                'plot': item.get('story', ''),
                'year': int(year) if year.isdigit() else 0,
                'studio': 'SimplySouth',
                'mediatype': 'movie'  # Essential for skin layouts
            }

            # Optional TMDB Enhancement
            tmdb = get_tmdb_meta(display_title, year)
            if tmdb:
                list_item.setArt({'poster': tmdb['poster'], 'fanart': tmdb['fanart']})
                info.update({'plot': tmdb['plot'], 'rating': tmdb['rating']})

            list_item.setInfo('video', info)
            
            url = f"{BASE_URL}?action=play&id={slug}&title={urllib.parse.quote(display_title)}"
            list_item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
        
        # Infinite Scroll
        if not query and len(items) >= 16:
            next_offset = int(offset) + 1
            add_dir(f"[COLOR yellow]Next Page >>>[/COLOR]", 
                    {'action': 'list_movies', 'lang': lang, 'genre': genre, 'offset': next_offset}, 
                    icon=SS_LOGO, fanart=SS_FANART)
            
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)

# --- 4. THE INSTANT PLAYER ---

def play_movie(slug, title):
    player_url = f"https://simplysouth.tv/player/{slug}/stream/0"
    try:
        r = requests.get(player_url, headers=get_all_headers(player_url), timeout=10)
        match = re.search(r"contentId\s*:\s*['\"](https?://[^'\"]+)['\"]", r.text)
        if match:
            stream_url = match.group(1)
            play_item = xbmcgui.ListItem(label=title, path=stream_url)
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            xbmcplugin.setResolvedUrl(HANDLE, True, play_item)
    except:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

# --- 5. ENTRY POINT ---

def add_dir(name, query, icon=None, fanart=None):
    url = f"{BASE_URL}?" + urllib.parse.urlencode(query)
    list_item = xbmcgui.ListItem(label=name)
    if icon: list_item.setArt({'icon': icon, 'thumb': icon})
    if fanart: list_item.setArt({'fanart': fanart})
    xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

if __name__ == '__main__':
    args = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    mode = args.get('action')
    
    if not mode:
        root_menu()
    elif mode == 'search_input':
        kb = xbmcgui.Dialog().input('Search SimplySouth', type=xbmcgui.INPUT_ALPHANUM)
        if kb: list_movies(query=kb)
    elif mode == 'list_genres': 
        list_genres(args['lang'])
    elif mode == 'list_movies':
        # Handles both navigation and skin search triggers
        list_movies(lang=args.get('lang'), 
                   genre=args.get('genre'), 
                   query=args.get('query'), 
                   offset=args.get('offset', 1))
    elif mode == 'play': 
        play_movie(args['id'], args.get('title'))