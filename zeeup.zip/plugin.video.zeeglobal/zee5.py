import sys
import time
import json
import base64
import re
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.parse import urlencode, parse_qsl, quote

# --- Addon Setup ---
ADDON = xbmcaddon.Addon()
try:
    HANDLE = int(sys.argv[1])
except:
    HANDLE = -1
BASE_URL = sys.argv[0]

# --- Constants ---
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"
DEVICE_ID = "b94f2a4a-f10e-4566-abce-9eadad51bbe0" 

def log(msg, level=xbmc.LOGINFO):
    """Helper to print to kodi.log"""
    xbmc.log(f"ZEE5-DEBUG: {msg}", level)

def get_uid_from_token(token):
    """Extracts the 'user_id' from the JWT Bearer payload."""
    if not token or '.' not in token:
        log("No valid token provided to extract UID.", xbmc.LOGWARNING)
        return 'unknown-uid'
        
    try:
        payload_b64 = token.split('.')[1]
        payload_b64 += '=' * (-len(payload_b64) % 4)
        payload_json = json.loads(base64.urlsafe_b64decode(payload_b64).decode('utf-8'))
        return payload_json.get('user_id', 'unknown-uid')
    except Exception as e:
        log(f"Failed to decode JWT to get UID: {e}", xbmc.LOGWARNING)
        return 'unknown-uid'

class ZeeGlobalAPI:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": USER_AGENT,
            "Referer": "https://www.zee5.com/",
            "Accept": "application/json",
            "sec-ch-ua-platform": '"Windows"'
        })
        self.x_dd_token = self._generate_x_dd_token()

    def _generate_x_dd_token(self):
        """Generates the base64 encoded device details token spoofing a 4K L1 Device"""
        payload = {
            "schema_version": "1", "os_name": "Android", "os_version": "14.0",
            "platform_name": "Shield", "platform_version": "145",
            "device_name": "Spoofed_4K_Device", "app_name": "AndroidTV", "app_version": "5.2.1",
            "player_capabilities": {
                "audio_channel": ["STEREO", "DOLBY", "ATMOS", "atmos"], 
                "video_codec": ["H265", "HEVC"],
                "container": ["MP4", "TS"], "package": ["DASH", "HLS"],
                "resolution": ["SD", "HD", "FHD", "UHD", "4K_HEVC"], 
                "dynamic_range": ["SDR", "HDR", "HDR10", "DOLBY"]
            },
            "security_capabilities": {
                "encryption": ["WIDEVINE_AES_CTR"], 
                "widevine_security_level": ["L1"], 
                "hdcp_version": ["HDCP_V1", "HDCP_V2", "HDCP_V2_1", "HDCP_V2_2"]
            }
        }
        json_string = json.dumps(payload, separators=(',', ':'))
        return base64.b64encode(json_string.encode('utf-8')).decode('utf-8')

    def fetch_platform_token(self, content_id):
        """Scrapes the dynamic X-Access-Token directly from the specific Zee5 video page."""
        url = f"https://www.zee5.com/b2b-consumption/{content_id}"
        try:
            r = self.session.get(url)
            match = re.search(r'"platform_token"\s*:\s*\{\s*"token"\s*:\s*"([^"]+)"', r.text)
            if match:
                return match.group(1)
            else:
                log("Could not find platform_token in HTML.", xbmc.LOGWARNING)
                return ""
        except Exception as e:
            log(f"Failed to fetch video page for platform token: {e}", xbmc.LOGERROR)
            return ""

    def authenticate_pairing_code(self, pairing_code):
        """Polls the partner endpoint to get the Premium Bearer Token."""
        url = "https://auth.zee5.com/partner/getdeviceuser"
        
        guest_string = "gBQaZLiNdGN9UsCKZaloghz9t9StWLSD"
        timestamp_ms = str(int(time.time() * 1000))
        raw_esk = f"{DEVICE_ID}__{guest_string}__{timestamp_ms}"
        esk_b64 = base64.b64encode(raw_esk.encode('utf-8')).decode('utf-8')

        headers = {
            "accept": "application/json",
            "content-type": "application/x-www-form-urlencoded",
            "device_id": DEVICE_ID,
            "esk": esk_b64,
            "x-z5-guest-token": DEVICE_ID,
            "origin": "https://www.zee5.com",
            "referer": "https://www.zee5.com/",
            "user-agent": USER_AGENT
        }
        
        payload = {"token": pairing_code}

        try:
            r = self.session.post(url, headers=headers, data=payload)
            r.raise_for_status()
            data = r.json()
            
            bearer_token = data.get("user", {}).get("token")
            refresh_token = data.get("user", {}).get("refresh_token")
            
            if bearer_token:
                log("Premium Bearer Token acquired successfully!")
                ADDON.setSetting("zee5_bearer_token", bearer_token)
                ADDON.setSetting("zee5_refresh_token", refresh_token)
                return bearer_token
            return None
        except Exception as e:
            log(f"Pairing authentication failed: {e}", xbmc.LOGERROR)
            return None

    def get_movies(self, page=1, lang="ml"):
        """Fetches the movie list."""
        url = "https://gwapi.zee5.com/v1/movie"
        params = {
            "page": page, "page_size": 20, "country": "IN",
            "asset_subtype": "movie", "translation": "en",
            "sort_by_field": "release_date", "sort_order": "desc",
            "version": "2", "languages": lang
        }
        try:
            r = self.session.get(url, params=params)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            log(f"Get Movies Error: {e}", xbmc.LOGERROR)
            return {}

    def get_playback(self, content_id, bearer_token, x_access_token):
        """Fetches the secure playback stream for a movie."""
        url = "https://spapi.zee5.com/singlePlayback/v2/getDetails/secure"
        user_uid = get_uid_from_token(bearer_token)
        
        params = {
            "content_id": content_id, "device_id": DEVICE_ID,
            "platform_name": "desktop_web", "translation": "en", "user_language": "en,hi",
            "country": "IN", "state": "MH", "app_version": "5.2.1", "user_type": "premium",
            "is_kids_profile": "false", "check_parental_control": "false", "utm_source": "XstreamPlay",
            "uid": user_uid, "ppid": DEVICE_ID, "version": "15"
        }
        
        headers = {
            "accept": "application/json",
            "authorization": f"bearer {bearer_token}",
            "content-type": "application/json",
            "origin": "https://www.zee5.com",
            "referer": "https://www.zee5.com/",
            "user-agent": USER_AGENT
        }
        
        payload = {
            "x-access-token": x_access_token,
            "Authorization": headers["authorization"],
            "x-dd-token": self.x_dd_token
        }
        
        try:
            r = self.session.post(url, params=params, headers=headers, json=payload)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            log(f"Playback API Error: {e}", xbmc.LOGERROR)
            return None

# --- Kodi UI & Routing Logic ---

api = ZeeGlobalAPI()

def list_malayalam_movies(page):
    """Lists movies in Kodi GUI"""
    xbmcplugin.setContent(HANDLE, 'movies')
    data = api.get_movies(page=page)
    items = data.get('items', [])
    
    if not items:
        xbmcgui.Dialog().notification('Zee5', 'No items found', xbmcgui.NOTIFICATION_INFO)
        return

    for item in items:
        title = item.get('title', 'Unknown')
        cid = item.get('id')
        plot = item.get('description', 'No description available.')
        duration = int(item.get('duration', 0))
        rating = float(item.get('rating', 0))
        year = int(item.get('release_date', '0000')[:4])
        mpaa = item.get('age_rating_new', '')
        actors = [a.split(':')[0] for a in item.get('actors', [])]

        li = xbmcgui.ListItem(label=title)
        
        info_tag = li.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setPlot(plot)
        info_tag.setMediaType('movie')
        info_tag.setDuration(duration)
        info_tag.setRating(rating)
        info_tag.setYear(year)
        info_tag.setMpaa(mpaa)
        if actors:
            info_tag.setCast([xbmcgui.InfoTagVideoCast(a) for a in actors])

        cover_hash = item.get('cover_image', '').replace('.jpg', '')
        poster = f"https://akamaividz2.zee5.com/image/upload/resources/{cid}/portrait/{cover_hash}.jpg"
        list_hash = item.get('list_image', '').replace('.jpg', '')
        fanart = f"https://akamaividz2.zee5.com/image/upload/resources/{cid}/list/{list_hash}.jpg"
        
        li.setArt({'thumb': poster, 'poster': poster, 'fanart': fanart})
        li.setProperty('IsPlayable', 'true')
        
        url = f"{BASE_URL}?action=play&id={cid}"
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    if len(items) >= 20:
        next_url = f"{BASE_URL}?action=list&page={int(page) + 1}"
        xbmcplugin.addDirectoryItem(HANDLE, next_url, xbmcgui.ListItem("Next Page >>"), True)
    
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(content_id):
    """Handles the lazy-loaded pairing code check, scrapes the platform token, and plays the stream."""
    play_item = xbmcgui.ListItem(path=f"plugin://{ADDON.getAddonInfo('id')}/")
    
    # 1. Check for existing Premium Token
    bearer_token = ADDON.getSetting("zee5_bearer_token")
    
    # 2. If no token, use the HARDCODED Pairing Code
    if not bearer_token:
        pairing_code = "01KJ4TDQP9AKZWQERMXV8TV7QR"
        
        # Attempt to authenticate with the provided code
        fetched_token = api.authenticate_pairing_code(pairing_code)
        
        if fetched_token:
            bearer_token = fetched_token 
            xbmcgui.Dialog().notification("Zee5", "Successfully Paired!", xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().notification("Zee5", "Invalid/Expired Pairing Code. Check log.", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(HANDLE, False, listitem=play_item)
            return

    # 3. Scrape the specific video page for the Platform Token
    x_access_token = api.fetch_platform_token(content_id)
    if not x_access_token:
        xbmcgui.Dialog().notification("Zee5", "Failed to get platform token", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=play_item)
        return

    # 4. Proceed to fetch Playback stream
    data = api.get_playback(content_id, bearer_token, x_access_token)
    
    if not data or 'assetDetails' not in data:
        xbmcgui.Dialog().notification("Zee5", "Failed to get playback stream (Token Expired?)", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=play_item)
        return
    
    asset_details = data.get('assetDetails', {})
    key_os = data.get('keyOsDetails', {})
    video_url = asset_details.get('video_url', {}).get('mpd') or key_os.get('hls_token')

    if video_url:
        header_params = {
            'User-Agent': USER_AGENT, 
            'Referer': 'https://www.zee5.com/', 
            'Origin': 'https://www.zee5.com'
        }
        header_string = '&'.join([f'{k}={quote(v)}' for k, v in header_params.items()])

        play_item.setPath(f"{video_url}|{header_string}")
        
        # Widevine DRM Setup for Kodi Inputstream Adaptive
        if 'sdrm' in key_os:
            lic_url = "https://spapi.zee5.com/widevine/getLicense"
            lic_hdr = f"Content-Type=application/octet-stream&customdata={key_os.get('sdrm')}&nl={key_os.get('nl')}"
            license_key = f"{lic_url}|{lic_hdr}|R{{SSM}}|"
            
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
            play_item.setProperty('inputstream.adaptive.license_key', license_key)
        
        play_item.setProperty('inputstream.adaptive.stream_headers', header_string)
        play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd' if '.mpd' in video_url else 'hls')
        play_item.setMimeType('application/dash+xml' if '.mpd' in video_url else 'application/vnd.apple.mpegurl')

        subs = asset_details.get('subtitle_url', [])
        if subs: 
            play_item.setSubtitles([subs[0].get('url')])

        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)
    else:
        xbmcplugin.setResolvedUrl(HANDLE, False, listitem=play_item)

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        list_malayalam_movies(1)
    elif params.get('action') == 'list':
        list_malayalam_movies(params.get('page', 1))
    elif params.get('action') == 'play':
        play_video(params.get('id'))

if __name__ == '__main__':
    router(sys.argv[2][1:])
