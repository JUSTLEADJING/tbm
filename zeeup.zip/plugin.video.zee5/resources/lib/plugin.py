import sys

from . import kodilogging
from . import kodiutils
from . import settings

import six
from six.moves import urllib_parse
from kodi_six import xbmc, xbmcaddon, xbmcplugin, xbmcgui

import re
import requests
import web_pdb
import uuid
import math
import logging
from json import dumps
import json
import random
import string
import time
from base64 import b64encode
import urllib.request
import urllib.parse
import urllib.error
from urllib.parse import quote

try:
    import itertools.imap as map
except ImportError:
    pass
import operator

import inputstreamhelper
try:
    import StorageServer
except:
    import storageserverdummy as StorageServer

_url = sys.argv[0]
_handle = int(sys.argv[1])
params = dict(urllib_parse.parse_qsl(sys.argv[2][1:]))

addon = xbmcaddon.Addon()
_settings = addon.getSetting
logger = logging.getLogger(addon.getAddonInfo('id'))
kodilogging.config()

_addonname = addon.getAddonInfo('name')
_icon = addon.getAddonInfo('icon')
_fanart = addon.getAddonInfo('fanart')

platform = 'desktop_web'
languages = settings.get_languages()
session = requests.Session()
ITEMS_LIMIT = 10

deviceid = addon.getSetting('deviceID')
ESK_SECRET_KEY = 'HOBNPuy7H3T5meJJAfyLkJlHaX2dXeEB'
if deviceid:
    device_id = deviceid
else:
    device_id = ''.join(random.choices(string.ascii_letters + string.digits, k=20)).ljust(32, '0')
    addon.setSetting("deviceid", device_id)

cache = StorageServer.StorageServer('zee5', 4)

headers = {
    "origin": "https://www.zee5.com",
    "referer": "https://www.zee5.com",
    "accept-encoding": "gzip, deflate, br",
    "accept-language": "en-US,en;q=0.9",
    "accept": "application/json, text/plain, */*",
    "content-type": "application/json",
    "cache-control": "no-cache"
}

try:
    platform_ua = re.findall(r'\(([^)]+)', xbmc.getUserAgent())[0]
except:
    platform_ua = 'Linux; Android 7.1.1'

USER_AGENT = "Mozilla/5.0 ({}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36 Firefox/95.0".format(platform_ua)
headers["user-agent"] = USER_AGENT


# ========================================================
# --- AUTHENTICATION & SPOOFING LOGIC ---
# ========================================================

def generate_x_dd_token():
    payload = {
        "schema_version": "1", "os_name": "Android", "os_version": "14.0",
        "platform_name": "Shield", "platform_version": "145",
        "device_name": "Spoofed_4K_Device", "app_name": "AndroidTV", "app_version": "5.2.1",
        "player_capabilities": {
            "audio_channel": ["ATMOS", "DOLBY", "ATMOS", "atmos"], 
            "video_codec": ["H265", "-hevc"],
            "container": ["MP4", "TS"], "package": ["DASH", "HLS"],
            "resolution": ["SD", "HD", "-4k-connected-hevc-aac", "-connected-atmos-hevc"], 
            "dynamic_range": ["SDR", "HDR", "HDR10", "DOLBY"]
        },
        "security_capabilities": {
            "encryption": ["WIDEVINE_AES_CTR"], 
            "widevine_security_level": ["L1"], 
            "hdcp_version": ["HDCP_V1", "HDCP_V2", "HDCP_V2_1", "HDCP_V2_2"]
        }
    }
    json_string = json.dumps(payload, separators=(',', ':'))
    return b64encode(json_string.encode('utf-8')).decode('utf-8')

def fetch_platform_token(content_id):
    url = "https://www.zee5.com/b2b-consumption/{}".format(content_id)
    try:
        r = requests.get(url, headers={"User-Agent": USER_AGENT})
        match = re.search(r'"platform_token"\s*:\s*\{\s*"token"\s*:\s*"([^"]+)"', r.text)
        if match: return match.group(1)
    except:
        pass
    return ""

def gen_esk():
    esk_string = "{}__{}__{}".format(device_id, ESK_SECRET_KEY, int(time.time() * 1000))
    return b64encode(esk_string.encode('utf-8')).decode('utf-8')

def send_otp(email):
    url = "https://auth.zee5.com/v1/user/sendotp"
    hdr = headers.copy()
    hdr.update({"device_id": device_id, "esk": gen_esk(), "x-z5-guest-token": device_id})
    payload = {"email": email}
    try:
        r = requests.post(url, headers=hdr, json=payload).json()
        if r.get("code") == 0: return True
    except:
        pass
    return False

def verify_otp(email, otp):
    url = "https://auth.zee5.com/v1/user/verifyotp"
    hdr = headers.copy()
    hdr.update({"device_id": device_id, "esk": gen_esk(), "x-z5-guest-token": device_id})
    payload = {
        "platform": "PWA", "otp": int(otp), "guest_token": device_id,
        "appsflyer_id": "65368gdbso90oNinja4AS133436", "lotame_cookie_id": "",
        "aid": "91955485578", "device": "Desktop", "version": "5.6.2", "email": email
    }
    try:
        r = requests.post(url, headers=hdr, json=payload).json()
        access_token = r.get("access_token")
        if access_token:
            addon.setSetting("zee5_bearer_token", access_token)
            headers.update({'Authorization': 'bearer ' + access_token})
            addon.setSetting("Authorization", 'bearer ' + access_token)
            xbmcgui.Dialog().notification(_addonname, "Login Successful!", xbmcgui.NOTIFICATION_INFO)
            return True
        else:
            xbmcgui.Dialog().notification(_addonname, "Login failed (No token)", xbmcgui.NOTIFICATION_ERROR)
    except:
        xbmcgui.Dialog().notification(_addonname, "Failed to verify OTP", xbmcgui.NOTIFICATION_ERROR)
    return False

def do_login():
    dialog = xbmcgui.Dialog()
    email = dialog.input("Enter your Zee5 Email Address:", type=xbmcgui.INPUT_ALPHANUM)
    if not email: return 
    dialog.notification(_addonname, "Sending OTP to email...", xbmcgui.NOTIFICATION_INFO)
    if send_otp(email):
        otp = dialog.input("Enter the 4-digit OTP sent to {}:".format(email), type=xbmcgui.INPUT_NUMERIC)
        if otp and len(str(otp)) >= 4:
            dialog.notification(_addonname, "Verifying...", xbmcgui.NOTIFICATION_INFO)
            verify_otp(email, otp)
        else:
            dialog.notification(_addonname, "Login cancelled.", xbmcgui.NOTIFICATION_WARNING)

def get_token():
    url = 'https://launchapi.zee5.com/launch?platform_name=web_app'
    try:
        data = requests.get(url, headers=headers).json()
        if 'platform_token' in data and 'token' in data['platform_token']:
            headers["x-access-token"] = data['platform_token']['token']
    except:
        pass

get_token()

def get_user():
    url = 'https://userapi.zee5.com/v1/user'
    hdr = headers.copy()
    hdr.update({"device_id": device_id, "esk": gen_esk(), "x-z5-guest-token": device_id})
    try:
        data = requests.get(url, headers=hdr).json()
        if not data.get('code'):
            headers.update({'uid': data.get('id', '')})
            headers.update({'country': data.get('registration_country', 'IN')})
    except:
        pass
    return

get_user()
country = headers.get('country') if headers.get('country') else 'IN'
country = 'IN'

if _settings("Authorization"):
    headers.update({"Authorization": _settings("Authorization")})


# ========================================================
# --- HIGH-RES IMAGE & METADATA HELPERS ---
# ========================================================

def get_high_res_art(img_dict, content_id):
    """Bypasses low-res API images and constructs uncompressed 1080p URLs."""
    poster = _icon
    fanart = _fanart
    
    if isinstance(img_dict, dict):
        # Grab the string, split by '/', keep only the last part (the filename), and remove .jpg
        raw_cover = str(img_dict.get('cover', img_dict.get('portrait', '')))
        cover_hash = raw_cover.split('/')[-1].replace('.jpg', '')
        
        raw_list = str(img_dict.get('list', ''))
        list_hash = raw_list.split('/')[-1].replace('.jpg', '')
        
        if cover_hash:
            poster = "https://akamaividz2.zee5.com/image/upload/resources/{}/portrait/{}.jpg".format(content_id, cover_hash)
        if list_hash:
            fanart = "https://akamaividz2.zee5.com/image/upload/resources/{}/list/{}.jpg".format(content_id, list_hash)
            if not cover_hash:
                poster = fanart
                
    return {'poster': poster, 'icon': poster, 'thumb': poster, 'fanart': fanart}


def set_list_item_details(list_item, labels):
    """Safely applies metadata and actors to Kodi UI."""
    try:
        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(labels.get('title', 'Unknown'))
        
        if labels.get('plot'): info_tag.setPlot(labels.get('plot'))
        if labels.get('year'): info_tag.setYear(int(labels.get('year')))
        if labels.get('aired'): info_tag.setPremiered(labels.get('aired'))
        if labels.get('duration'): info_tag.setDuration(int(labels.get('duration')))
        if labels.get('episode'): info_tag.setEpisode(int(labels.get('episode')))
        if labels.get('mediatype'): info_tag.setMediaType(labels.get('mediatype'))
        if labels.get('tvshowtitle'): info_tag.setTvShowTitle(labels.get('tvshowtitle'))
        
        if labels.get('genre') and labels.get('genre') != 'ALL':
            info_tag.setGenres(labels.get('genre').split(','))
            
        # Parse Actors and Roles (ActorName:RoleName)
        actors = labels.get('castandrole', [])
        if actors:
            cast_list = []
            for a in actors:
                parts = str(a).split(':')
                actor_name = parts[0]
                role_name = parts[1] if len(parts) > 1 else ""
                cast_item = xbmcgui.InfoTagVideoCast(actor_name)
                if role_name:
                    cast_item.setRole(role_name)
                cast_list.append(cast_item)
            info_tag.setCast(cast_list)
    except AttributeError:
        # Fallback for Kodi 18/19
        list_item.setInfo('video', labels)


# ========================================================
# --- CLEANED UP MENU LOGIC (MOVIES & TV SHOWS ONLY) ---
# ========================================================

def clear_cache():
    msg = 'Cached Data has been cleared'
    cache.table_name = 'zee5'
    cache.cacheDelete('%get%')
    addon.setSetting("Authorization", "")
    addon.setSetting("zee5_bearer_token", "")
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % (_addonname, msg, 3000, _icon))

def get_genre(item):
    if not item: return 'ALL'
    genres = set()
    for genreField in ['genre', 'genres']:
        data = item.get(genreField)
        if not data: continue
        genres.update(map(operator.itemgetter('value'), data))
    return ",".join(list(genres)) if genres else 'ALL'

def go_page(sid, Stype, total):
    pnum = xbmcgui.Dialog().numeric(0, 'Enter Page Number')
    if int(pnum) > int(total): pnum = total
    if Stype == 'Episode': list_episodes(sid, pnum)
    elif Stype == 'Show': list_shows(sid, pnum)
    else: list_season(sid, pnum, Stype)
    return

def get_user_input():
    kb = xbmc.Keyboard('', 'Search for Movies/TV Shows in all languages')
    kb.doModal() 
    if not kb.isConfirmed(): return
    return kb.getText()

def get_search(query, page):
    url = 'https://contentapi.zee5.com/content/search?q={}&limit={}&page={}&country={}&translation=en&version=8&languages={}&filters='.format(
        urllib_parse.quote_plus(query), ITEMS_LIMIT, page, country, languages
    )
    try:
        data = requests.get(url, headers=headers).json()
    except:
        return []
        
    if not data.get('total_count'):
        kodiutils.notification('No Search Results', 'No item found for {}'.format(query))
        return []
        
    listing = []
    for item in data.get('results', []):
        title = item.get('title', 'Unknown')
        sid = item.get('id')
        mediatype = item.get('contentType')
        icon = get_high_res_art(item.get('image_url', {}), sid)
        labels = {'title': title, 'genre': get_genre(item),
                  'year': item.get('release_date')[:4] if item.get('release_date') else None,
                  'aired': item.get('release_date')[:10] if item.get('release_date') else None,
                  'duration': item.get('duration') if item.get('duration') else None,
                  'castandrole': item.get('actors', []),
                  'mediatype': 'video'}
        listing.append((title, icon, labels, sid, mediatype, page))

    page = int(page)
    totals = int(data.get('total_count', 0))
    itemsleft = totals - page * 10
    finalpg = True
    if itemsleft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 10.0))

    if not finalpg:
        page += 1
        title = 'Next Page.. (Currently in Page %s of %s)' % (page, pages)
        labels = {}
        icon = {'poster': _icon, 'icon': _icon, 'thumb': _icon, 'fanart': _fanart}
        listing.append((title, icon, labels, sid, mediatype, page))
    return listing

def list_search(query, page):
    if page == '0':
        query = get_user_input()
        if not query: return []
    shows = get_search(query, page)
    listing = []
    if not shows: return
    for title, icon, labels, sid, stype, pnum in shows:
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]' % title)
        list_item.setArt(icon)
        set_list_item_details(list_item, labels)
        if 'Next Page' in title:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=search&query={1}&page={2}'.format(_url, query, pnum)
            is_folder = True
        elif stype in ['Show']:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=list_season&sid={1}&page=1&showtype={2}'.format(_url, sid, stype)
            is_folder = True
        else:
            list_item.setProperty('IsPlayable', 'true')
            url = '{0}?action=playNew&vid={1}&sid={2}&itemtype=MOVIE'.format(_url, sid, sid)
            is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)

def get_top():
    top = []
    top.append(('🔑 Login to Zee5 (OTP)', 'login_btn'))
    
    url = 'https://b2bapi.zee5.com/front/countrylist.php?lang=en&ccode={}'.format(country)
    try:
        data = requests.get(url, headers=headers).json()
        mains = data[0].get('collections', {}).get('html5_app', {})
        for name, collection_id in six.iteritems(mains):
            title = name.title()
            cid = collection_id
            # STRIPPED: Only include Movie and TV Show related categories
            if any(x in title.lower() for x in ['movie', 'show', 'series', 'premium']):
                top.append((title, cid))
    except:
        pass
        
    title = 'Search'
    cid = 1
    top.append((title, cid))
    title = 'Clear Cache'
    cid = 2
    top.append((title, cid))
    return top

def list_top():
    items = get_top()
    listing = []
    for title, cid in items:
        list_item = xbmcgui.ListItem(label=title)
        if 'Search' in title:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=search&query=FIRST&page=0'.format(_url)
            is_folder = True
        elif 'Clear Cache' in title:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=clear_cache'.format(_url)
            is_folder = True
        elif 'Login' in title:
            list_item.setLabel('[B][COLOR yellow]%s[/COLOR][/B]' % title)
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=login'.format(_url)
            is_folder = True
        else:
            list_item.setInfo('video', {'title': title})
            list_item.setProperty('IsPlayable', 'false')
            list_item.setArt({'poster': _icon, 'icon': _icon, 'thumb': _icon, 'fanart': _fanart})
            url = '{0}?action=list_item&cid={1}&page=1'.format(_url, cid)
            is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)

def get_channels(cid, page):
    channels = []
    url = 'https://gwapi.zee5.com/content/collection/{id}?country={country}&page={page}&limit={limit}&translation=en&item_limit=10&languages={lang}&version=10'.format(
        id=cid, country=country, page=page, limit=ITEMS_LIMIT, lang=languages)
    try:
        data = requests.get(url, headers=headers).json()
    except:
        return channels

    for bucket in data.get('buckets', []):
        if not bucket.get('items'): continue
        bid = bucket.get('id')
        title = bucket.get('title', 'Unknown')
        asset_subtype = bucket.get('asset_subtype')
        icon = get_high_res_art(bucket['items'][0].get('image_url', {}), bid)
        labels = {'title': title, 'plot': bucket.get('description')}
        channels.append((title, icon, bid, labels, asset_subtype))

    page = int(page)
    totals = int(data.get('total', 0))
    itemsleft = totals - page * 10
    finalpg = True
    if itemsleft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 10.0))

    if not finalpg:
        title = 'Next Page.. (Currently in Page %s of %s)' % (page, pages)
        page += 1
        icon = {'poster': _icon, 'icon': _icon, 'thumb': _icon, 'fanart': _fanart}
        labels = {}
        channels.append((title, icon, page, labels, ''))
    return channels

def list_channels(cid, page):
    channels = cache.cacheFunction(get_channels, cid, page)
    listing = []
    if not channels: return
    for title, icon, bid, labels, subtype in channels:
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]' % title)
        if 'Next Page' in title:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=list_item&cid={1}&page={2}'.format(_url, cid, bid)
            is_folder = True
        else:
            list_item.setProperty('IsPlayable', 'false')
            list_item.setArt(icon)
            set_list_item_details(list_item, labels)
            url = '{0}?action=list_shows&showid={1}&page=1'.format(_url, bid)
            is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)

def get_shows(showid, page):
    shows = []
    url = 'https://gwapi.zee5.com/content/collection/{id}?country={country}&page={page}&limit={limit}&languages={lang}&translation=en&version=10'.format(
        id=showid, country=country, page=page, limit=ITEMS_LIMIT, lang=languages)
    try:
        data = requests.get(url, headers=headers).json()
    except:
        return shows
        
    buckets = data.get('buckets', [])
    if not buckets: return shows
    
    seasons = buckets[0].get('items', [])
    for season in seasons:
        title = season.get('title', 'Unknown')
        description = season.get('description')
        stype = season.get('asset_subtype')

        if stype == 'external_link':
            slug = season.get('slug', '')
            stype = slug.split('/')[3] if slug[:4] == 'http' else slug.split('/')[0]
            stype = stype[:-1] if stype else ''
            content_id = slug.rsplit('/', 2)[1] if slug.rsplit('/', 1)[-1] == 'latest1' else slug.rsplit('/', 1)[-1]
            show_id = season.get('id') if season.get('id') else content_id
        else:
            content_id = season.get('id')
            show_id = season.get('tvshow', {}).get('id') if season.get('tvshow') else content_id
            
        if stype in ['movie', 'video', 'clip', 'episode', 'collection', 'trailer']:
            mediatype = 'movie'
        else:
            mediatype = 'tvshow'
            
        icon = get_high_res_art(season.get('image_url', {}), content_id)
        labels = {'title': title, 'genre': get_genre(season),
                  'castandrole': season.get('actors', []),
                  'plot': description,
                  'year': season.get('release_date')[:4] if season.get('release_date') else None,
                  'aired': season.get('release_date')[:10] if season.get('release_date') else None,
                  'duration': season.get('duration') if season.get('duration') else None,
                  'mediatype': mediatype}
        shows.append((title, icon, content_id, show_id, labels, stype))

    page = int(page)
    totals = int(data.get('total', 0))
    itemsleft = totals - page * 10
    finalpg = True
    if itemsleft > 0:
        finalpg = False
        pages = int(math.ceil(totals / 10.0))

    if not finalpg:
        title = 'Next Page.. (Currently in Page %s of %s)' % (page, pages)
        page += 1
        labels = {}
        icon = {'poster': _icon, 'icon': _icon, 'thumb': _icon, 'fanart': _fanart}
        shows.append((title, icon, content_id, page, labels, pages))
        title = "Go Page..."
        shows.append((title, icon, content_id, page, labels, pages))
    return shows

def list_shows(showid, page):
    shows = cache.cacheFunction(get_shows, showid, page)
    listing = []
    if not shows: return
    for title, icon, cid, sid, labels, stype in shows:
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]' % title)
        list_item.setArt(icon)
        set_list_item_details(list_item, labels)

        if 'Next Page' in title:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=list_shows&showid={1}&page={2}'.format(_url, showid, sid)
            is_folder = True
        elif "Go Page" in title:
            list_item.setProperty("IsPlayable", "false")
            url = "{0}?action=gopage&sid={1}&Stype={2}&total={3}".format(_url, showid, 'Show', stype)
            is_folder = True
        else:
            if stype in ['video', 'clip', 'episode', 'webisode', 'collection', 'trailer']:
                list_item.setProperty('IsPlayable', 'true')
                url = '{0}?action=playNew&vid={1}&sid={2}&itemtype=EPISODE'.format(_url, cid, sid)
                is_folder = False
                xbmcplugin.setContent(_handle, 'episodes')
            elif stype in ['movie']:
                list_item.setProperty('IsPlayable', 'true')
                url = '{0}?action=playNew&vid={1}&sid={2}&itemtype=MOVIE'.format(_url, cid, sid)
                is_folder = False
                xbmcplugin.setContent(_handle, 'movies')
            else:
                list_item.setProperty('IsPlayable', 'false')
                url = '{0}?action=list_season&sid={1}&page=1&showtype={2}'.format(_url, cid, stype)
                is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)

def get_season(season_id, page, showtype):
    season = []
    stype = 'collection' if showtype == 'Manual' else 'tvshow'
    url = 'https://gwapi.zee5.com/content/{stype}/{id}?country={country}&page={page}&limit={limit}&languages={lang}&version=10'.format(
        stype=stype, id=season_id, country=country, page=page, limit=ITEMS_LIMIT, lang=languages)
    try:
        data = requests.get(url, headers=headers).json()
    except:
        return season
        
    if showtype == 'Manual':
        buckets = data.get('buckets', [])
        seasons = buckets[0].get('items', []) if buckets else []
    else:
        seasons = data.get('seasons', [])
        
    for show in seasons:
        subtype = show.get('asset_subtype') if showtype == 'Manual' else data.get('asset_subtype')
        rdate = show.get('release_date')[:10] if show.get('release_date') else None
        desc = show.get('description') if showtype == 'Manual' else data.get('description')
        mediatype = 'movie' if subtype in ['movie', 'video', 'clip', 'webisode', 'trailer'] else 'tvshow'
            
        sid = show.get('id')
        stitle = show.get('title', 'Unknown')
        icon = get_high_res_art(show.get('image_url', {}), sid)
        labels = {'title': stitle, 'genre': get_genre(data), 'mediatype': mediatype, 'plot': desc, 'aired': rdate, 'castandrole': show.get('actors', [])}
        season.append((stitle, icon, sid, labels, subtype))

    if showtype == 'Manual':
        page = int(page)
        totals = int(data.get('total', 0))
        itemsleft = totals - page * 10
        finalpg = True
        if itemsleft > 0:
            finalpg = False
            pages = int(math.ceil(totals / 10.0))

        if not finalpg:
            stitle = 'Next Page.. (Currently in Page %s of %s)' % (page, pages)
            page += 1
            labels = {}
            icon = {'poster': _icon, 'icon': _icon, 'thumb': _icon, 'fanart': _fanart}
            season.append((stitle, icon, page, labels, pages))
            stitle = "Go Page..."
            season.append((stitle, icon, page, labels, pages))
    return season

def list_season(seasonid, page, showtype):
    shows = cache.cacheFunction(get_season, seasonid, page, showtype)
    listing = []
    if not shows: return
    for title, icon, sid, labels, stype in shows:
        list_item = xbmcgui.ListItem(label='[COLOR yellow]%s[/COLOR]' % title)
        list_item.setArt(icon)
        set_list_item_details(list_item, labels)
        if 'Next Page' in title:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=list_season&sid={1}&page={2}&showtype={3}'.format(_url, seasonid, sid, showtype)
            is_folder = True
        elif "Go Page" in title:
            list_item.setProperty("IsPlayable", "false")
            url = "{0}?action=gopage&sid={1}&Stype={2}&total={3}".format(_url, seasonid, showtype, stype)
            is_folder = True
        else:
            if stype in ['movie', 'video', 'clip', 'webisode', 'trailer']:
                list_item.setProperty('IsPlayable', 'true')
                url = '{0}?action=playNew&vid={1}&sid={2}&itemtype=EPISODE'.format(_url, sid, seasonid)
                is_folder = False
                xbmcplugin.setContent(_handle, 'movie')
            else:
                list_item.setProperty('IsPlayable', 'false')
                url = '{0}?action=list_episodes&sid={1}&page=1'.format(_url, sid)
                is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)

def get_episodes(episodeid, page):
    episodes = []
    page = int(page)
    url = 'https://gwapi.zee5.com/content/tvshow/?season_id={id}&type=episode&translation=en&country={country}&on_air=true&asset_subtype=tvshow&page={page}&limit={limit}'.format(
        id=episodeid, country=country, page=page, limit=ITEMS_LIMIT)
    try:
        data = requests.get(url, headers=headers).json()
    except:
        return episodes
        
    items = data.get('episode', [])
    for item in items:
        etitle = 'Episodes {} - {}'.format(item.get('episode_number'), six.ensure_str(item.get('title', ''), encoding='utf-8', errors='ignore'))
        eid = item.get('id')
        showid = item.get('tvshow', {}).get('id')
        plot = item.get('description')
        eptype = item.get('asset_subtype')
        icon = get_high_res_art(item.get('image_url', {}), eid)
        labels = {'title': etitle, 'genre': get_genre(item), 'plot': plot, 'duration': item.get('duration'),
                  'episode': item.get('episode_number'), 'tvshowtitle': etitle, 'year': item.get('release_date')[:4] if item.get('release_date') else None,
                  'aired': item.get('release_date')[:10] if item.get('release_date') else None, 'mediatype': 'episode', 'castandrole': item.get('actors', [])}
        episodes.append((etitle, eid, icon, labels, eptype, showid))
        
    total = data.get('total', 0)
    balcount = int(total) - page * 10
    if balcount > 0:
        pages, mod = divmod(int(total), 10)
        pages = pages + 1 if mod > 0 else pages
        etitle = 'Next Page... (Page %s of %s)' % (page, pages)
        page += 1
        labels = {}
        icon = {'poster': _icon, 'icon': _icon, 'thumb': _icon, 'fanart': _fanart}
        episodes.append((etitle, page, icon, labels, eptype, showid))
        etitle = 'Go Page...'
        icon = {'poster': _icon, 'icon': _icon, 'thumb': _icon, 'fanart': _fanart}
        episodes.append((etitle, page, icon, labels, eptype, pages))
    return episodes

def list_episodes(eid, page):
    episodes = cache.cacheFunction(get_episodes, eid, page)
    listing = []
    if not episodes: return
    for etitle, epid, icon, labels, eptype, showid in episodes:
        list_item = xbmcgui.ListItem(label=etitle)
        list_item.setArt(icon)
        set_list_item_details(list_item, labels)
        if 'Next Page' in etitle:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=list_episodes&sid={1}&page={2}'.format(_url, eid, epid)
            is_folder = True
        elif 'Go Page' in etitle:
            list_item.setProperty('IsPlayable', 'false')
            url = '{0}?action=gopage&sid={1}&Stype={2}&total={3}'.format(_url, eid, 'Episode', showid)
            is_folder = True
        else:
            list_item.setProperty('IsPlayable', 'true')
            url = '{0}?action=playNew&vid={1}&sid={2}&itemtype=EPISODE'.format(_url, epid, showid)
            is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.setContent(_handle, 'episodes')
    xbmcplugin.endOfDirectory(_handle)


# ========================================================
# --- PLAYBACK LOGIC (EXACTLY AS YOU PROVIDED) ---
# ========================================================

def playNew(item_id, show_id, item_type):
    play_item = xbmcgui.ListItem(path=f"plugin://{addon.getAddonInfo('id')}/")
    userid = headers.get('uid', '')

    url = "https://spapi.zee5.com/singlePlayback/getDetails/secure"
    if item_type == 'EPISODE':
        url += '?content_id={}&show_id={}&device_id={}&platform_name={}&translation=en&user_language={}&country={}&app_version=2.51.26&user_type=register&check_parental_control=false&uid={}&ppid={}&version=12'.format(
            item_id, show_id, device_id, platform, languages, country, userid, device_id)
    elif item_type == 'MOVIE':
        url += '?content_id={}&device_id={}&platform_name={}&translation=en&user_language={}&country={}&app_version=2.51.26&user_type=register&check_parental_control=false&uid={}&ppid={}&version=12'.format(
            item_id, device_id, platform, languages, country, userid, device_id)
    else:
        url += '?channel_id={}&device_id={}&platform_name={}&translation=en&user_language={}&country={}&app_version=2.51.26&user_type=register&check_parental_control=false&uid={}&ppid={}&version=12'.format(
            item_id, device_id, platform, languages, country, userid, device_id)

    body_dict = {}
    if headers.get('Authorization'):
        body_dict["Authorization"] = headers.get('Authorization')
    else:
        body_dict["X-Z5-Guest-Token"] = device_id
        
    body_dict["x-access-token"] = headers.get('x-access-token', '')
    body_dict["x-dd-token"] = generate_x_dd_token()
    
    body = dumps(body_dict)

    try:
        data = requests.post(url, headers=headers, data=body).json()
    except Exception as e:
        xbmc.log("ZEE5 EXCEPTION [playNew]: " + str(e), xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(_handle, False, listitem=xbmcgui.ListItem())
        return

    if data.get('error_code') == '3608' or data.get('error_code') == '401':
        xbmcgui.Dialog().notification(_addonname, "Token Expired. Try Logging in again.", xbmcgui.NOTIFICATION_WARNING)
            
    if data.get('error_msg'):
        xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % (_addonname, data.get('error_msg'), 3000, _icon))
        xbmcplugin.setResolvedUrl(_handle, False, listitem=xbmcgui.ListItem())
        return

    asset_details = data.get('assetDetails', {})
    key_os = data.get('keyOsDetails', {})
    video_url = asset_details.get('video_url', {}).get('mpd') or key_os.get('hls_token')

    # ---------------------------------------------------------
    # --- CASCADING MANIFEST INJECTION ---
    # ---------------------------------------------------------
    if video_url and '.mpd' in video_url:
        parsed_url = urllib_parse.urlparse(video_url)
        old_file_name = parsed_url.path.split("/")[-1]
        
        def url_exists(test_url):
            try:
                req = urllib.request.Request(test_url, method='HEAD')
                req.add_header('User-Agent', USER_AGENT)
                with urllib.request.urlopen(req, timeout=3) as response:
                    return response.status == 200
            except urllib.error.URLError:
                return False
            except Exception:
                return False

        manifest_options = [
            "-connected-4k",
            "-4k-connected-hevc-aac",
            "-connected-ddplus-hevc",
            "-connected-ddplus-avc",
            "-connected"
        ]

        found_better_manifest = False
        for option in manifest_options:
            new_file_name = "manifest{}.mpd".format(option)
            new_path = parsed_url.path.replace(old_file_name, new_file_name)
            test_url = urllib_parse.urlunparse(parsed_url._replace(path=new_path))
            
            if url_exists(test_url):
                video_url = test_url
                xbmc.log("ZEE5-DEBUG: Injected manifest: {}".format(new_file_name), xbmc.LOGINFO)
                found_better_manifest = True
                break

        if not found_better_manifest:
            xbmc.log("ZEE5-DEBUG: Premium manifests not found. Falling back to original: {}".format(old_file_name), xbmc.LOGINFO)
    # ---------------------------------------------------------

    if video_url:
        header_params = {
            'User-Agent': USER_AGENT, 
            'Referer': 'https://www.zee5.com/', 
            'Origin': 'https://www.zee5.com'
        }
        header_string = '&'.join(['{}={}'.format(k, quote(str(v))) for k, v in header_params.items()])

        play_item.setPath("{}|{}".format(video_url, header_string))
        
        # Widevine DRM Setup for Kodi Inputstream Adaptive
        if 'sdrm' in key_os:
            customdata = key_os.get('sdrm', '')
            nl = key_os.get('nl', '')
            lic_url = 'https://spapi.zee5.com/widevine/getLicense'
            
            # --- INJECT AUTH TOKENS INTO DRM REQUEST ---
            auth_token = headers.get('Authorization', '')
            x_access = headers.get('x-access-token', '')
            
            lic_headers = {
                'Content-Type': 'application/octet-stream',
                'Authorization': auth_token,
                'x-access-token': x_access,
                'customdata': customdata,
                'nl': nl
            }
            
            lic_hdr = '&'.join(['{}={}'.format(k, urllib_parse.quote(str(v))) for k, v in lic_headers.items() if v])
            license_key = '{}|{}|R{{SSM}}|'.format(lic_url, lic_hdr)
            # -------------------------------------------
            
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
            play_item.setProperty('inputstream.adaptive.license_key', license_key)
        
        play_item.setProperty('inputstream.adaptive.stream_headers', header_string)
        play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd' if '.mpd' in video_url else 'hls')
        play_item.setMimeType('application/dash+xml' if '.mpd' in video_url else 'application/vnd.apple.mpegurl')

        subs = asset_details.get('subtitle_url', [])
        if subs: 
            play_item.setSubtitles([subs[0].get('url')])

        xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    else:
        xbmcplugin.setResolvedUrl(_handle, False, listitem=play_item)


def router(paramstring):
    params = dict(urllib_parse.parse_qsl(paramstring))

    if params:
        if params['action'] == 'login':
            do_login()
        elif params['action'] == 'list_item':
            list_channels(params['cid'], params['page'])
        elif params['action'] == 'list_shows':
            list_shows(params['showid'], params['page'])
        elif params['action'] == 'list_season':
            list_season(params['sid'], params['page'], params['showtype'])
        elif params['action'] == 'list_episodes':
            list_episodes(params['sid'], params['page'])
        elif params['action'] == 'playNew':
            playNew(params['vid'], params['sid'], params['itemtype'])
        elif params['action'] == 'search':
            list_search(params['query'], params['page'])
        elif params['action'] == 'gopage':
            go_page(params['sid'], params['Stype'], params['total'])
        elif params['action'] == 'clear_cache':
            clear_cache()
    else:
        list_top()


def run():
    kodiutils.cleanup_temp_dir()
    router(sys.argv[2][1:])

run()
