import sys
import urllib.parse
import re
import requests
import json
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

# --- 1. CONFIGURATION ---
ADDON = xbmcaddon.Addon()
BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])

# USER CONFIG
AUTH_TOKEN = "1e793998500e2183849920a1987b7a16"
USER_ID = "7989896"

# UI Assets
SS_LOGO = "https://m.media-amazon.com/images/I/21M0DCO2QVL.png"
SS_FANART = "https://m.media-amazon.com/images/I/31cH-rlAmJL.png"

# --- 2. HELPERS ---

def get_app_headers():
    return {
        'User-Agent': 'Simply South/3 CFNetwork/3860.300.31 Darwin/25.2.0',
        'Content-Type': 'application/x-www-form-urlencoded',
        'authToken': AUTH_TOKEN,
        'Accept': '*/*',
        'Accept-Language': 'en-AU,en;q=0.9',
    }

def clean_title(title):
    if not title: return "Unknown"
    return re.sub(r'\s*(?:Telugu|Tamil|Malayalam|Kannada|4K|Dolby Atmos|Atmos|HD|UHD)\s*', '', title, flags=re.IGNORECASE).strip()

def get_lang_code(full_lang):
    mapping = {'Malayalam': 'mal', 'Tamil': 'tam', 'Telugu': 'tel', 'Kannada': 'kan'}
    return mapping.get(full_lang, 'mal')

def add_dir(name, query, icon=None, fanart=None, is_folder=True):
    url = f"{BASE_URL}?" + urllib.parse.urlencode(query)
    li = xbmcgui.ListItem(label=name)
    if icon: li.setArt({'icon': icon, 'thumb': icon})
    if fanart: li.setArt({'fanart': fanart})
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)

# --- 3. NAVIGATION ---

def root_menu():
    add_dir("[COLOR yellow][B]Search Movies[/B][/COLOR]", {'action': 'search_input'}, icon=SS_LOGO, fanart=SS_FANART)
    langs = ['Malayalam', 'Tamil', 'Telugu', 'Kannada']
    for lang in langs:
        add_dir(lang, {'action': 'language_menu', 'lang': lang}, icon=SS_LOGO, fanart=SS_FANART)
    xbmcplugin.endOfDirectory(HANDLE)

def language_menu(lang):
    add_dir(f"All {lang} Movies", {'action': 'list_movies', 'lang': lang}, icon=SS_LOGO, fanart=SS_FANART)
    add_dir(f"{lang} Genres", {'action': 'genre_menu', 'lang': lang}, icon=SS_LOGO, fanart=SS_FANART)
    xbmcplugin.endOfDirectory(HANDLE)

def genre_menu(lang):
    genres = ['Action', 'Comedy', 'Drama', 'Thriller', 'Romance', 'Crime', 'Horror', 'Family']
    for g in genres:
        add_dir(g, {'action': 'list_movies', 'lang': lang, 'genre': g}, icon=SS_LOGO, fanart=SS_FANART)
    xbmcplugin.endOfDirectory(HANDLE)

# --- 4. MOVIE LISTING & SEARCH ---

def list_movies(lang=None, query=None, genre=None, offset=1):
    # Ensure offset is an integer for math, default to 1 if it arrives as None/Empty
    try:
        current_page = int(offset)
    except (ValueError, TypeError):
        current_page = 1

    # Determine Endpoint
    if query:
        api_url = f"https://simplysouth.tv/rest/searchData?q={urllib.parse.quote(query)}"
    elif genre:
        api_url = f"https://simplysouth.tv/rest/getContentList?genre%5B%5D={urllib.parse.quote(genre)}"
    else:
        api_url = "https://simplysouth.tv/rest/getContentList"
    
    payload = {
        'limit': '20',
        'country': 'AU',
        'user_id': USER_ID,
        'orderby': 'releasedate',
        'permalink': 'movie',
        'offset': str(current_page), # SimplySouth uses page numbers 1, 2, 3...
        'authToken': AUTH_TOKEN,
        'result_type': '1'
    }

    if not query and lang:
        payload['custom_input'] = json.dumps([{"value": get_lang_code(lang), "custom_key": "language"}])

    try:
        r = requests.post(api_url, data=payload, headers=get_app_headers(), timeout=10)
        data = r.json()
        # Search returns "search" key, Catalog returns "movieList"
        items = data.get('search') if query else data.get('movieList', [])
    except Exception as e:
        xbmc.log(f"SimplySouth API Error: {str(e)}", xbmc.LOGERROR)
        items = []

    if items:
        for item in items:
            name = clean_title(item.get('title') or item.get('name'))
            permalink = item.get('permalink')
            
            li = xbmcgui.ListItem(label=name)
            poster = item.get('poster') or item.get('poster_url')
            fanart = item.get('content_banner') or item.get('mobile_banner', item.get('tv_banner'))
            li.setArt({'poster': poster, 'fanart': fanart, 'thumb': poster})
            
            # --- CAST & CREW ---
            cast_list = []
            directors = []
            casting = item.get('casting', {})
            if isinstance(casting, dict):
                # Actors and Actresses
                actors = casting.get('actor', []) + casting.get('actress', [])
                for person in actors:
                    cast_list.append({
                        'name': person.get('celeb_name'), 
                        'role': person.get('cast_type_name', 'Actor'), 
                        'thumbnail': person.get('celeb_image')
                    })
                # Directors
                for director in casting.get('director', []):
                    directors.append(director.get('celeb_name'))

            video_info = {
                'title': name,
                'plot': item.get('story') or item.get('short_story'),
                'year': int(item.get('release_date', '0000')[:4]) if item.get('release_date') else 0,
                'mediatype': 'movie',
                'director': directors,
                'genre': item.get('genres') if isinstance(item.get('genres'), list) else []
            }
            
            li.setInfo('video', video_info)
            li.setCast(cast_list)
            
            url = f"{BASE_URL}?action=play&slug={permalink}"
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

        # --- PAGINATION ---
        if len(items) >= 20:
            next_page = current_page + 1
            nav_params = {'action': 'list_movies', 'offset': next_page}
            
            # Carry forward filters
            if lang: nav_params['lang'] = lang
            if genre: nav_params['genre'] = genre
            if query: nav_params['query'] = query
            
            add_dir(f"[COLOR yellow]Next Page ({next_page}) >>>[/COLOR]", nav_params, icon=SS_LOGO)

    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)

# --- 5. PLAYER LOGIC ---

def play_movie(slug):
    xbmc.log(f"SimplySouth: Resolving {slug}", xbmc.LOGINFO)
    
    # Step 1: Get internal IDs
    details_url = f"https://simplysouth.tv/rest/getContentDetails?permalink={slug}"
    try:
        r1 = requests.post(details_url, headers=get_app_headers())
        movie_data = r1.json().get('movie', {})
        
        # Step 2: Exchange IDs for HLS URL
        video_url = "https://simplysouth.tv/rest/getVideoDetails"
        payload_v = {
            'stream_uniq_id': movie_data.get('movie_stream_uniq_id'),
            'content_uniq_id': movie_data.get('muvi_uniq_id'),
            'user_id': USER_ID,
            'authToken': AUTH_TOKEN,
            'license_type': '2',
            'device_type': '7'
        }
        
        r2 = requests.post(video_url, data=payload_v, headers=get_app_headers())
        video_data = r2.json()
        
        stream_link = video_data.get('non_drm_hls_url') or video_data.get('hls_url') or video_data.get('videoUrl')
        if not stream_link: 
            raise Exception("No playable stream found in API response")

        # Add User-Agent to the stream URL for Kodi's internal player
        final_url = stream_link + "|User-Agent=" + urllib.parse.quote(get_app_headers()['User-Agent'])
        
        li = xbmcgui.ListItem(path=final_url)
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        
        # Subtitles
        subs = [s['url'] for s in video_data.get('subTitle', []) if s.get('url')]
        if subs: 
            li.setSubtitles(subs)

        xbmcplugin.setResolvedUrl(HANDLE, True, li)
        
    except Exception as e:
        xbmc.log(f"SimplySouth Play Error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Playback Error', 'Could not resolve stream', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

# --- 6. ENTRY POINT ---

if __name__ == '__main__':
    # Parse URL parameters
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')

    if not action:
        root_menu()
    elif action == 'language_menu':
        language_menu(params.get('lang'))
    elif action == 'genre_menu':
        genre_menu(params.get('lang'))
    elif action == 'list_movies':
        list_movies(
            lang=params.get('lang'), 
            query=params.get('query'), 
            genre=params.get('genre'), 
            offset=params.get('offset', 1)
        )
    elif action == 'search_input':
        kb = xbmcgui.Dialog().input('Search SimplySouth', type=xbmcgui.INPUT_ALPHANUM)
        if kb: 
            list_movies(query=kb)
    elif action == 'play':
        play_movie(params.get('slug'))