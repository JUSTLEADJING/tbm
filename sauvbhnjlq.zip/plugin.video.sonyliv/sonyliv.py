import sys
import urllib.parse
import json
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import re

# Plugin constants
HANDLE = int(sys.argv[1])
ADDON = xbmcaddon.Addon()

def logger(message, level=xbmc.LOGINFO):
    xbmc.log(f"[SonyLIV_V2] {message}", level)

HEADERS = {
    "accept": "application/json, text/plain, */*",
    "accept-encoding": "gzip, deflate, br, zstd",
    "accept-language": "en-AU,en-GB;q=0.9,en-US;q=0.8,en;q=0.7,zh-CN;q=0.6,zh-CN;q=0.5",
    "advertiserid": "d5d6432532f442fd82b4a12a0de540f1-1768988937078",
    "app_version": "3.6.38",
    "authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMTliZGZmNjk2ZTI3NzlhYWJlMThkMTU4Y2VmZWRmMCIsInRva2VuIjoiMUNlWC1VaERlLVFuSEstczFwZC1FZThBLUFic2MtTFAiLCJleHBpcmF0aW9uTW9tZW50IjoiMjAyNy0wMS0yMVQwOTo1MDozOS4zMzBaIiwiaXNQcm9maWxlQ29tcGxldGUiOmZhbHNlLCJzZXNzaW9uQ3JlYXRpb25UaW1lIjoiMjAyNi0wMS0yMVQwOTo1MDozOS4zMzBaIiwiY2hhbm5lbFBhcnRuZXJJRCI6Ik1TTUlORCIsImZpcnN0TmFtZSI6IiIsIm1vYmlsZU51bWJlciI6IjYyODI2Nzg5NzMiLCJkYXRlT2ZCaXJ0aCI6IiIsImdlbmRlciI6IiIsInByb2ZpbGVQaWMiOiIiLCJzb2NpYWxQcm9maWxlUGljIjoiIiwic29jaWFsTG9naW5JRCI6bnVsbCwic29jaWFsTG9naW5UeXBlIjpudWxsLCJpc0VtYWlsVmVyaWZpZWQiOmZhbHNlLCJpc01vYmlsZVZlcmlmaWVkIjp0cnVlLCJsYXN0TmFtZSI6IiIsImVtYWlsIjoiIiwiaXNDdXN0b21lckVsaWdpYmxlRm9yRnJlZVRyaWFsIjpmYWxzZSwiY29udGFjdElEIjoiMTMyOTYzMzAzNCIsImlhdCI6MTc2ODk4OTAzOSwiZXhwIjoxODAwNTI1MDM5fQ._BiBOtpKZFwA7w4GTrWSrkcCPKbc1RRkSxzt96pPXX0",
    "cache-control": "no-cache",
    "cookie": "bm_mi=79A4482ACBADA7C008C5B3910D7A779F~YAAQPwNiaAj1hNabAQAAfLFa6R7u/Xlt0h5X3/KJo4tuziFWl6mtcJ/qedbcYWYX+VSGdGoith4MCj75aIDmnxtGMKbNDeKRsj+yVAonwo/TJBdB43pf7dqnFozyGrR5teO6dH49WmDaEK2W6WTNOo/qIp+FsG8NshqHeARHd6q+vavkrm3WM6WtX7sY6UB0t0CYJBwu0BDyvJ4gtKSlDbNhNK1ODIIv7Bwv1uMCl4p7iSAR3R6opWacl7F4J8RVjN4XS48pMjzVkMNhhjQhKiA1o17igmF7EB6AkhQ7fsxv3wgbfQw7PlIl/fIxmhc=~1; ak_bmsc=CABA21CD5C71D00358E4E52A5FCDA108~000000000000000000000000000000~YAAQPwNiaHD/hNabAQAAX/da6R6xNKWY8dWr757nPBJRr53q3OwKjEseJF3Q0RLna1yeOhWUUzcORHX/GwGKc2A4HE6eEj41t7Y/POdIC9BQlxMmOaGDmsvBaf2psMcDxTShJWLf9oEwKzzWJUKblhED0wRNfsPm8Ib6tbxdM8xqLzOcXaVW2+SlVgjZkOlmyf0A4Npn+xLvj+L/ZI6sB0Gmptp+pI0l8yHR6fEg3XPR2iXBxqhJz5DJJEsTdRV32lSOtl2RohjxEpN3ishJvGi8ADQVi5F2qNB/I9I8i+4DS2yZwp3vqZrK1DkM7XpyDtD162Urtg7dwqQIYqgNCm9YEDAiPBFXtLdxaVohTHea5P842tENrSl+TN9G6tbHKeNvSuIl7c5xtG4837irBTk40G71Fa8MIxm/TX+dXicU; AKA_A2=A; _abck=0AF993CC31A83815E63D45A2A4A1581F~0~YAAQh3xCF8sk38ObAQAAqZSZ6Q+xJ8fcrjsRGKA7Sdbc94jV2H+fnfzFvJwKq7CHwZ3zPSpNDmWAgLym+PU1U8hXWmEbCLvr1XiyVXgXMj8lgF1FFOeKeAoP66vb8xLHCu7F9YEItNduwXgOMzx19vhjibCi1T9S/mkeaJXPvJaknWjt0vJsElVkQuP2FUZstdG3+yRUzsrKNHSMF3otZwv4gCzhu5oBw93FBWrJZFE7Zq12fVHdZA3rdOmTqyKqxVe4PpFUokDk4g5BlB8el6CBJwGdF8vtkQJJL7FfF20ir0sMF/RltP4cz/PgyLycrWI4/fXM2FAO+lFSDuM46dd/jD6bX+y0kquFqjaqRbi9Q5jmHOuGEm/49kE6M8wi2QrFgssYpBn8GxvACV9oPjjhSkgQJehbQA5YHTnwRgisB7MsJSQCRP49jzhFcYyis8MN2X5t7elMn7k9bMIP6IPYvitzfr4OWDzFbPhjzK6c6ia3b+n7GuxhoTtEHt4q/eGXamLYPAz9V+QFsRKCo2OEOwTBhqjjoDQ7bqPDfGb2wWXa8yA9pdOGPVuRCvDPNNVJzp9NyjQPsIC3AkusfJF/q6gS6woDomsGFadlEwJLnbR44Q9Vvh86XvlHxts7cgcjwiH4NRtuXSOd3CuwD1DQwb3P3Rf+VTyhaoFbhz1NFg2iOF4PooGfjIfG2cblfx/HUzjTZVqYooDpPDgFq8btCn/fbzwNdS4UIWByztTVZPqdLH2Jj86C7S+NTYGkNAnZdqnirQ9XBNyd3dvyK2bztXFjm45+3G3+yUaqtdixmkxBBnSXgvxKrHso2ITn5L672qkdc+ps8vei73rNLAohEiG+LJxMTzKGM35+gclpDm9irVrFva06+8H2Pm0txb3xvhyKFTSH0tC1aF9c1Qog1MUsTebqSCrp3KMananiaiabJ/BmvfEc7/4yM72HssIUm1sEkRtpC+fto0meipbSXshgfYr3HiXe618LQyF/6L2BtXO7B2CyNxIGp0FnJdT+axRh6uzVH0JFsefxl5t2A1yb3kKEUIWB9cA7ShTFir+deTZadJgV9fck7WbwBlI2r5UlmXYmnX1SVhkr5Bx+LhnuT3tFgPjhIWIOARqjj/237Wn9pNUamoF8s6HO9w==~-1~-1~-1~AAQAAAAF%2f%2f%2f%2f%2fxp5eTdWJgtd4Ls1eUgKhXz2xF8hNnA2t8OHGA6QDIWZ39axLGe65F6FhnLtTApXTUEWfpOeM9vYa9L23YQY2wr93ViMBFQu5tJQv0E+2V07AZxTknI2ihmW0+K2te25tBZA%2fkqRIscnZ6X2%2fZeKj+JuAbTBkvj4AZ63TqqTgaSgdK17+cGaYF6EPoyK313fn8qU1K4u8x7s7eQk7kOWGgPUVdm1GU+oOBfhuF0XIJFAyJY%3d~-1; bm_sz=B9A379ACE0845FF8D8FD3FC3CDA1A4DB~YAAQ06TBF+xY5cabAQAAXQOc6R7/9YecQunJixSQ9rsvRFPb80ZPDvF5xAQHT/cBYWaM+3Mh5w+vzS1E9f7Y71aFtNAQSM0fYX+uvaadRb5bCW33DSxzjRtwPfgf8OP2BCsdZmSh0eTtSIvZFAQbtiK6PZiIAqKW+sZ2hIsDfLt+BQZCnRagmTpLqoQzaM+VwaE7koocrU0i0pa/Ac8TUq3pucxIpaipbEwUuGCdCJ7dtlUEEc7XGYig60h7NvjK3T50kGslC5OkyFhArf8L/eAT0mJX0a9XNJcIu94QBgrEjqUAa5p+OYm0hFJUH9OspEsvjw5nwvXQ3chr4EOimyaEmQCEKiOHch0KBdYwKFK2PrKI1NUNuNJsLHtMGYvZPVHOlBXg93RHHl6+SFn28yRc6Qcy8/V3GcE4uXBDf6ZlaE4Y5GosLKzDdSygIpN6+8pRnsf56o6o6R+jOVEfzMY+mVphwyrv+2EmTVCWE3CkZNIRbWbH4ZDjOWNW8tj+kUEvxI1UcVWekG8+AxgyA1BwjKwVjUvy~4535858~4536377; sessionId=3775ef4ae4e44029977f5b3ac043b1cd-1769150875675; bm_sv=589F14DA578B63A8EF60E7388E6E5A46~YAAQhzTVF+C+WsGbAQAAv3qd6R7r1X0+Oat/jqkKD91ATKmxATRT23mYpPcFq23h5auxoq4P4IgRPglzFAyfqvAkccENnGnvjTdHlfuzn+Jov99VMDN18PVT842v/GRJwmgKRalDw9W7BDH/UV7gbCnbjN40XwbsEEFphIm7Xrv7wNh91HMsFEZvjrboqISgdQC25jcgL9IwS3dtqhvIL2PBNkBx+qHkECOgr7Iz4VU7n40wSAAOfpccsFT/K4rBJgWQ~1",
    "device_id": "d5d6432532f442fd82b4a12a0de540f1-1768988937078",
    "origin": "https://www.sonyliv.com",
    "referer": "https://www.sonyliv.com/",
    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
    "x-via-device": "true"
}

def get_url(**kwargs):
    return f"{sys.argv[0]}?{urllib.parse.urlencode(kwargs)}"

def list_categories():
    url = "https://apiv3.sonyliv.com/AGL/4.8/SR/ENG/WEB/IN/PB/PAGE-V2/69112"
    params = {'from': '0', 'to': '9', 'packageId': 'LIV_Pre_6M', 'isOnboarding': 'true'}
    try:
        res = requests.get(url, headers=HEADERS, params=params).json()
        for container in res.get('resultObj', {}).get('containers', []):
            title = container.get('title')
            uri = container.get('retrieveItems', {}).get('uri')
            if title and uri:
                list_item = xbmcgui.ListItem(label=title)
                url = get_url(action='list_tray', uri=uri, start=0)
                xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

def list_tray_items(uri, start=0):
    start = int(start)
    end = start + 14
    if '?' in uri:
        clean_uri = uri.split('?')[0]
        existing_params = dict(urllib.parse.parse_qsl(uri.split('?')[1]))
        existing_params.update({'from': start, 'to': end})
        url = f"https://apiv3.sonyliv.com/AGL/4.8/SR/ENG/WEB/IN/PB{clean_uri}?{urllib.parse.urlencode(existing_params)}"
    else:
        url = f"https://apiv3.sonyliv.com/AGL/4.8/SR/ENG/WEB/IN/PB{uri}?from={start}&to={end}"

    try:
        res = requests.get(url, headers=HEADERS).json()
        result_obj = res.get('resultObj', {})
        for item in result_obj.get('containers', []):
            bundle_id = item.get('id')
            meta = item.get('metadata', {})
            title = meta.get('title') or item.get('title', 'Unknown')
            emf = meta.get('emfAttributes', {})
            poster = emf.get('portrait_thumb') or emf.get('image_600x900_clean')
            fanart = emf.get('tv_background_image') or emf.get('detail_cover_bg')

            if bundle_id:
                list_item = xbmcgui.ListItem(label=title)
                list_item.setArt({'thumb': poster, 'poster': poster, 'fanart': fanart})
                list_item.setInfo('video', {'title': title, 'plot': meta.get('longDescription'), 'mediatype': 'movie'})
                list_item.setProperty('IsPlayable', 'true')
                url_play = get_url(action='play_video', bundle_id=bundle_id)
                xbmcplugin.addDirectoryItem(HANDLE, url_play, list_item, isFolder=False)

        total_items = result_obj.get('total', 0)
        if end < total_items:
            next_start = end + 1
            next_page_uri = result_obj.get('retrieveItems', {}).get('uri') or uri
            list_item = xbmcgui.ListItem(label="Next Page >>")
            url_next = get_url(action='list_tray', uri=next_page_uri, start=next_start)
            xbmcplugin.addDirectoryItem(HANDLE, url_next, list_item, isFolder=True)
    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

def resolve_asset_id(bundle_id):
    url = f"https://apiv2.sonyliv.com/AGL/4.8/SR/ENG/WEB/IN/MH/USER/RECOMMENDATION/DETAIL/{bundle_id}"
    params = {'contactId': '1329633034', 'kids_safe': 'false', 'from': '0', 'to': '9', 'segment_id': 'AB_DetailPage_Disable'}
    try:
        res = requests.get(url, headers=HEADERS, params=params).json()
        match = re.search(r'sony://asset/(\d+)', json.dumps(res))
        if match: return match.group(1)
    except: pass
    return None

def play_video(bundle_id):
    asset_id = resolve_asset_id(bundle_id)
    if not asset_id: return

    api_url = f"https://apiv2.sonyliv.com/AGL/4.8/SR/ENG/WEB/IN/UP/CONTENT/VIDEOURL/VOD/{asset_id}?contactId=1329633034"
    payload = {
        "actionType": "play", "browser": "Chrome", "deviceId": HEADERS['device_id'],
        "os": "Mac OS", "platform": "web", "hasLAURLEnabled": True,
        "adsParams": {"Idtype": "uuid", "Is_lat": "0", "ppid": "c01539bf3e22bac2cad7393887abe066"}
    }

    try:
        response = requests.post(api_url, headers=HEADERS, json=payload).json()
        result = response.get('resultObj', {})
        video_url = result.get('videoURL')
        la_url = result.get('LA_Details', {}).get('laURL')
        sub_list = result.get('subtitle', [])

        if video_url:
            ua = HEADERS['user-agent']
            cookie = HEADERS['cookie']
            session = HEADERS['device_id']
            adaptive_headers = (
                f"User-Agent={ua}&Cookie={cookie}&x-playback-session-id={session}&"
                f"Accept=*/*&Accept-Encoding=gzip, deflate, br, zstd&"
                f"Origin=https://www.sonyliv.com&Referer=https://www.sonyliv.com/&"
                f"Sec-Fetch-Site=same-site"
            )

            play_item = xbmcgui.ListItem(path=f"{video_url}|{adaptive_headers}")
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', adaptive_headers)
            
            # SUBTITLE EXTRACTION LOGIC
            if sub_list:
                # Find English track (prioritizing 'ENG' code)
                english_sub = next((s for s in sub_list if s.get('subtitleLanguageName') == 'ENG'), None)
                if english_sub:
                    sub_url = english_sub.get('subtitleUrl')
                    logger(f"Found English Subtitle: {sub_url}")
                    # Pass the URL as a list to setSubtitles
                    play_item.setSubtitles([sub_url])
            
            if la_url:
                wv_headers = (
                    "Accept=*/*&Accept-Encoding=gzip, deflate, br, zstd&"
                    "Accept-Language=en-AU,en-GB;q=0.9,en-US;q=0.8,en;q=0.7,zh-CN;q=0.6&"
                    "Content-Type=application/octet-stream&Origin=https://www.sonyliv.com&"
                    "Pragma=no-cache&Referer=https://www.sonyliv.com/&Sec-Fetch-Dest=empty&"
                    "Sec-Fetch-Mode=cors&Sec-Fetch-Site=cross-site&"
                    f"User-Agent={ua}"
                )
                play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                play_item.setProperty('inputstream.adaptive.license_key', f"{la_url}|{wv_headers}|R{{SSM}}|")

            xbmcplugin.setResolvedUrl(HANDLE, True, play_item)
    except Exception as e:
        logger(f"Subtitle/Playback logic error: {str(e)}")

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    if not params: list_categories()
    elif params['action'] == 'list_tray': list_tray_items(params['uri'], start=params.get('start', 0))
    elif params['action'] == 'play_video': play_video(params.get('bundle_id'))

if __name__ == '__main__':
    router(sys.argv[2][1:])