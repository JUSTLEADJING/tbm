import sys
import urllib.parse
import json
import base64
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
from Cryptodome.Cipher import AES

# --- 1. CONFIGURATION ---
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
APP_SECRET = "A3s68aORSgHs$71P"
AES_IV = b'\x00' * 16

DEFAULT_BACKDROP = "https://www.sunnxt.com/images/logins_bgimg.jpg"
DEFAULT_ICON = "https://www.sunnxt.com/images/logo/logo.png"

BASE_HEADERS = {
    'accept': '*/*',
    'accept-encoding': 'gzip, deflate, br, zstd',
    'accept-language': 'en',
    'cache-control': 'no-cache',
    'origin': 'https://www.sunnxt.com',
    'pragma': 'no-cache',
    'priority': 'u=1, i',
    'referer': 'https://www.sunnxt.com/',
    'sec-ch-ua': '"Google Chrome";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"macOS"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
    'x-myplex-platform': 'browser',
    'x-ucv': '4',
    'cookie': '_tt_enable_cookie=1; _ttp=01KET2Y1FJDXX53ZCBENAR4330_.tt.1; _gcl_au=1.1.1670632800.1768254539; _ga=GA1.1.740999252.1768254540; _fbp=fb.1.1768254541570.385217131213453246; WZRK_G=f72c378ffcac4b93bd3b0199e663cec7; sessionid=v6sahzwgzv7brh3ty6ms6emcyyf3oig7; afUserId=2c904145-fd96-4725-9ebb-f2b3c38e99e3-p; AF_SYNC=1768254547274; _gcl_aw=GCL.1768709536.Cj0KCQiAg63LBhDtARIsAJygHZ4Y5UZocmPa1BpycAxRsxezUO-wNDVVxqWRlDdp8MLSPf2KEXqm5cIaAsjHEALw_wcB; _gcl_gs=2.1.k1$i1768709531$u189562025; __gads=ID=2944bfdfb75f8760:T=1768255102:RT=1768718970:S=ALNI_MY75jq5z2Xx8KjxMisds46MCvjEGQ; __gpi=UID=000011e37b1a05b9:T=1768255103:RT=1768718970:S=ALNI_MbB0qua1PFSi2L0XBDCeaKataN9hQ; __eoi=ID=bca97337f1a9aa7c:T=1768255103:RT=1768718970:S=AA-AfjaDHBwfYY_1I82kGiZD_hVu; WZRK_S_WW6-54K-855Z=%7B%22s%22%3A1768715638%2C%22t%22%3A1768720784%2C%22p%22%3A13%7D; ttcsid=1768709535461::0lwK5D-4Odr9bJ4cTQrk.4.1768720851937.0::1.11315982.10815932::11315337.155.698.2271::11316414.754.0; ttcsid_CFN0QG3C77UCCRP9FAKG=1768709535460::5JgoaA048BaDDl_wu3eQ.4.1768720851937.1; _ga_M4Z38WW7QV=GS2.1.s1768715638$o5$g1$t1768720852$j60$l0$h1585424428'
}

def log(msg):
    xbmc.log(f"SUNNXT_DEBUG >> {msg}", xbmc.LOGINFO)

def decrypt_data(encrypted_base64):
    try:
        key = APP_SECRET.encode('utf-8')
        enc_data = base64.b64decode(encrypted_base64.strip())
        cipher = AES.new(key, AES.MODE_CBC, AES_IV)
        decrypted = cipher.decrypt(enc_data)
        padding_len = decrypted[-1]
        decrypted = decrypted[:-padding_len]
        return json.loads(decrypted.decode('utf-8'))
    except Exception as e:
        log(f"Decryption Failure: {str(e)}")
        return None

# --- 2. NAVIGATION ---

def root_menu():
    languages = ["malayalam", "tamil", "telugu", "kannada", "hindi", "bengali", "marathi", "english"]
    for lang in languages:
        query = {'action': 'list_lang_sections', 'lang': lang}
        add_dir(lang.capitalize(), query, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_lang_sections(lang):
    add_dir("[COLOR yellow]Movies[/COLOR]", {'action': 'list_group', 'lang': lang, 'group': 'portalMovies'}, isFolder=True)
    add_dir("[COLOR cyan]TV Shows[/COLOR]", {'action': 'list_group', 'lang': lang, 'group': 'portalTvShows'}, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_group(lang, group):
    url = f"https://pwaapi.sunnxt.com/content/v2/carousel/_info?group={group}&language={lang}"
    headers = BASE_HEADERS.copy()
    headers['contentlanguage'] = lang
    try:
        r = requests.get(url, headers=headers).json()
        for item in r.get('results', []):
            title = item.get('title', 'Unknown')
            cat_id = item.get('name')
            images = item.get('images', [])
            thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
            query = {'action': 'list_content', 'cat_id': cat_id, 'lang': lang, 'start': '1'}
            add_dir(title, query, thumb, isFolder=True)
    except Exception as e: log(f"Group Discovery Error: {str(e)}")
    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(global_service_id, lang, start_index):
    """Fetches list of episodes for a specific show using the GID API"""
    url = f"https://pwaapi.sunnxt.com/content/v3/vods/{global_service_id}/?&orderBy=releaseDate&orderMode=-1&fields=contents,user/currentdata,images,generalInfo,relatedCast,globalServiceName,globalServiceId,publishingHouse&startIndex={start_index}&count=30&contentlang={lang}"
    headers = BASE_HEADERS.copy()
    headers['contentlanguage'] = lang
    try:
        r = requests.get(url, headers=headers).json()
        results = r.get('results', [])
        for item in results:
            g = item.get('generalInfo', {})
            # Use displayTitle for "E19 - Jan 16, 2026" style labels
            ep_title = g.get('displayTitle', 'Unknown Episode')
            plot = g.get('description', '')
            images = item.get('images', {}).get('values', [])
            thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
            
            query = {'action': 'play', 'id': item.get('_id'), 'title': ep_title, 'thumb': thumb}
            item_url = f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"
            list_item = xbmcgui.ListItem(label=ep_title)
            list_item.setArt({'thumb': thumb, 'poster': thumb})
            list_item.setProperty('IsPlayable', 'true')
            
            info = list_item.getVideoInfoTag()
            info.setTitle(ep_title)
            info.setPlot(plot)
            xbmcplugin.addDirectoryItem(HANDLE, item_url, list_item, isFolder=False)
            
        if len(results) >= 30:
            next_start = int(start_index) + 1
            query = {'action': 'list_episodes', 'gid': global_service_id, 'lang': lang, 'start': str(next_start)}
            add_dir("[COLOR gold]Next Page >>>[/COLOR]", query, isFolder=True)
    except Exception as e: log(f"Episode Listing Error: {str(e)}")
    xbmcplugin.endOfDirectory(HANDLE)

def list_content(cat_id, lang, start_index):
    url = f"https://pwaapi.sunnxt.com/content/v2/carousel/{cat_id}?level=devicemax&startIndex={start_index}&count=24&contentlang={lang}"
    headers = BASE_HEADERS.copy()
    headers['contentlanguage'] = lang
    try:
        r = requests.get(url, headers=headers).json()
        results = r.get('results', [])
        for item in results:
            g = item.get('generalInfo', {})
            title = g.get('title', 'Unknown')
            
            # Handle nested promotions (folders)
            if g.get('type') == 'promotion':
                action_url = g.get('actionURL', '')
                nested_id = action_url.split('/')[-1].split('?')[0] if '/' in action_url else ""
                images = item.get('images', {}).get('values', [])
                thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
                query = {'action': 'list_content', 'cat_id': nested_id, 'lang': lang, 'start': '1'}
                add_dir(f"[COLOR cyan]{title}[/COLOR]", query, thumb, isFolder=True)
            
            # Handle TV Shows (Individual Series Categories)
            elif item.get('globalServiceId'):
                gid = item.get('globalServiceId')
                images = item.get('images', {}).get('values', [])
                thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
                query = {'action': 'list_episodes', 'gid': gid, 'lang': lang, 'start': '1'}
                add_dir(title, query, thumb, isFolder=True)

            # Handle direct Movies or VODs
            else:
                alt_title = ""
                for alt in g.get('altTitle', []):
                    if alt.get('language') == 'type': alt_title = alt.get('title')
                plot = f"{alt_title}\n\n{g.get('description', '')}" if alt_title else g.get('description', '')
                images = item.get('images', {}).get('values', [])
                thumb = next((img['link'] for img in images if img.get('profile') == 'xxhdpi'), "")
                
                query = {'action': 'play', 'id': item.get('_id'), 'title': title, 'thumb': thumb}
                item_url = f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"
                list_item = xbmcgui.ListItem(label=title)
                list_item.setArt({'thumb': thumb, 'poster': thumb})
                list_item.setProperty('IsPlayable', 'true')
                
                info = list_item.getVideoInfoTag()
                info.setTitle(title)
                info.setPlot(plot)
                xbmcplugin.addDirectoryItem(HANDLE, item_url, list_item, isFolder=False)
        
        if len(results) >= 24:
            next_start = int(start_index) + 1
            next_query = {'action': 'list_content', 'cat_id': cat_id, 'lang': lang, 'start': str(next_start)}
            add_dir("[COLOR gold]Next Page >>>[/COLOR]", next_query, isFolder=True)
            
    except Exception as e: log(f"Listing Error: {str(e)}")
    xbmcplugin.endOfDirectory(HANDLE)

# --- 3. THE RESOLVER ---

def play_video(content_id, title):
    log(f"--- RESOLVING NAGRA DRM FOR ID: {content_id} ---")
    api_url = f"https://www.sunnxt.com/next/api/media/{content_id}?playbackCounter=1&fields=videos,generalInfo&licenseType=false"
    try:
        r = requests.get(api_url, headers=BASE_HEADERS, timeout=10)
        data = decrypt_data(r.json().get('response', ''))
        video_item = data['results'][0]['videos']['values'][0]
        mpd_url = video_item['link']
        license_url = video_item['licenseUrl'] 
        token = license_url.split('token=')[1] if 'token=' in license_url else ""
        lic_headers = {
            'User-Agent': BASE_HEADERS['user-agent'],
            'Cookie': BASE_HEADERS['cookie'],
            'Content-Type': 'application/octet-stream',
            'Referer': 'https://www.sunnxt.com/',
            'Origin': 'https://www.sunnxt.com',
            'nv-authorizations': token 
        }
        header_str = urllib.parse.urlencode(lic_headers)
        license_key = f"{license_url}|{header_str}|R{{SSM}}|"
        play_item = xbmcgui.ListItem(label=title, path=mpd_url)
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
        play_item.setProperty('inputstream.adaptive.license_key', license_key)
        play_item.setProperty('inputstream.adaptive.max_video_resolution', '720')
        xbmcplugin.setResolvedUrl(HANDLE, True, play_item)
    except Exception as e:
        log(f"Play Crash: {str(e)}")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

def add_media_entry(item, title, thumb):
    # Use the specific thumb if it exists, otherwise use the global logo
    img_thumb = thumb if thumb else DEFAULT_ICON
    # Use thumb as fanart if available, otherwise use the global backdrop
    img_fanart = thumb if thumb else DEFAULT_BACKDROP
    
    query = {'action': 'play', 'id': item.get('_id'), 'title': title, 'thumb': img_thumb}
    item_url = f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"
    list_item = xbmcgui.ListItem(label=title)
    
    # Apply artwork to every link
    list_item.setArt({
        'thumb': img_thumb,
        'icon': img_thumb,
        'fanart': img_fanart,      # Sets the background for this link
        'poster': img_thumb
    })
    
    list_item.setProperty('IsPlayable', 'true')
    info = list_item.getVideoInfoTag()
    info.setTitle(title)
    info.setPlot(item.get('generalInfo', {}).get('description', ''))
    xbmcplugin.addDirectoryItem(HANDLE, item_url, list_item, isFolder=False)


def add_dir(name, query, thumb=None, isFolder=True):
    url = f"{sys.argv[0]}?{urllib.parse.urlencode(query)}"
    item = xbmcgui.ListItem(label=name)
    
    # Determine artwork
    img_thumb = thumb if thumb else DEFAULT_ICON
    img_fanart = thumb if thumb else DEFAULT_BACKDROP
    
    # Apply to directory items
    item.setArt({
        'thumb': img_thumb,
        'icon': img_thumb,
        'fanart': img_fanart
    })
    
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=isFolder)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    if not action: root_menu()
    elif action == 'list_lang_sections': list_lang_sections(params['lang'])
    elif action == 'list_group': list_group(params['lang'], params['group'])
    elif action == 'list_content': list_content(params['cat_id'], params['lang'], params.get('start', '1'))
    elif action == 'list_episodes': list_episodes(params['gid'], params['lang'], params.get('start', '1'))
    elif action == 'play': play_video(params['id'], params['title'])