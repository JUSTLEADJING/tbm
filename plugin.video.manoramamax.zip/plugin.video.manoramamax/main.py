import sys
import urllib.parse
import re
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

# --- 1. CONFIGURATION ---
ADDON = xbmcaddon.Addon()
BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])

# UI Branding - UPDATED AS REQUESTED
MAX_LOGO = "https://www.manoramamax.com/images/manorama/Manoramamax_icon_512.png"
MAX_FANART = "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/ManoramaMAX_logo.jpg/845px-ManoramaMAX_logo.jpg"
GENRE_IMG_BASE = "https://d229kpbsb5jevy.cloudfront.net/mmtv/content/"

USER_COOKIE = "_gcl_au=1.1.1953525201.1768668898; _ga=GA1.1.1755483339.1768668899; _boxId_v3=%2205b0dc25-da97-6e59-c554-a4614cecd0f0%22; _sessionId_v3=%225c583f4a-ddc6-4455-9b93-36911771db92%22; tenant-code=manoramamax;"

def get_headers():
    return {
        'accept': 'application/json, text/plain, */*',
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
        'box-id': '05b0dc25-da97-6e59-c554-a4614cecd0f0',
        'session-id': '5c583f4a-ddc6-4455-9b93-36911771db92',
        'tenant-code': 'manoramamax',
        'origin': 'https://www.manoramamax.com',
        'referer': 'https://www.manoramamax.com/',
        'cookie': USER_COOKIE
    }

# --- 2. NAVIGATION ---

def root_menu():
    add_dir("[COLOR yellow][B]Search[/B][/COLOR]", {'action': 'search_input'}, icon=MAX_LOGO, fanart=MAX_FANART)
    add_dir("Latest Movies", {'action': 'list_page_content', 'path': 'section/latest-movies-page'}, icon=MAX_LOGO, fanart=MAX_FANART)
    add_dir("Browse By Genre", {'action': 'fetch_subsections', 'path': 'section/browse-by-genre'}, icon=MAX_LOGO, fanart=MAX_FANART)
    add_dir("Artist", {'action': 'fetch_subsections', 'path': 'section/artist'}, icon=MAX_LOGO, fanart=MAX_FANART)
    add_dir("All Movies", {'action': 'list_page_content', 'path': 'section/all-movies'}, icon=MAX_LOGO, fanart=MAX_FANART)
    add_dir("Mazhavil Classics", {'action': 'mazhavil_menu'}, icon=MAX_LOGO, fanart=MAX_FANART)
    xbmcplugin.endOfDirectory(HANDLE)

def mazhavil_menu():
    add_dir("TV Serials", {'action': 'list_page_content', 'path': 'section/mazhavil-classics'}, icon=MAX_LOGO, fanart=MAX_FANART)
    add_dir("Reality Shows", {'action': 'list_page_content', 'path': 'section/reality-shows'}, icon=MAX_LOGO, fanart=MAX_FANART)
    add_dir("Popular Comedy Shows", {'action': 'list_page_content', 'path': 'section/popular-comedy-shows'}, icon=MAX_LOGO, fanart=MAX_FANART)
    add_dir("Popular Shows", {'action': 'list_page_content', 'path': 'section/popular-shows'}, icon=MAX_LOGO, fanart=MAX_FANART)
    add_dir("Cookery Shows", {'action': 'list_page_content', 'path': 'section/cookery-shows'}, icon=MAX_LOGO, fanart=MAX_FANART)
    add_dir("Dance Reality Shows", {'action': 'list_page_content', 'path': 'section/dance-reality-shows'}, icon=MAX_LOGO, fanart=MAX_FANART)
    xbmcplugin.endOfDirectory(HANDLE)

# --- 3. DYNAMIC DISCOVERY HANDLERS ---

def fetch_subsections(path):
    api_url = "https://mmtvmax-api.revlet.net/service/api/v1/page/content"
    params = {'path': path, 'count': 40}
    try:
        r = requests.get(api_url, params=params, headers=get_headers()).json()
        data_block = r.get('response', {}).get('data', [{}])[0]
        rows = data_block.get('section', {}).get('sectionData', {}).get('data', [])
        for item in rows:
            display = item.get('display', {})
            target = item.get('target', {})
            title = display.get('title') or display.get('name')
            img = display.get('imageUrl', '')
            if "browse-by-genre" in path and img and not img.startswith('http'):
                img = f"{GENRE_IMG_BASE}{img.replace(',', '/')}"
            if title and target.get('path'):
                add_dir(title, {'action': 'list_page_content', 'path': target.get('path')}, icon=img, fanart=MAX_FANART)
    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

def list_page_content(path):
    api_url = "https://mmtvmax-api.revlet.net/service/api/v1/page/content"
    params = {'path': path, 'count': 40}
    try:
        r = requests.get(api_url, params=params, headers=get_headers()).json()
        data_blocks = r.get('response', {}).get('data', [])
        if 'programs/detail' in path:
            for block in data_blocks:
                if block.get('paneType') == 'section':
                    info = block.get('section', {}).get('sectionInfo', {})
                    if 'range' in info.get('code', ''):
                        add_dir(info.get('name'), {'action': 'list_range_episodes', 'path': path, 'code': info.get('code')}, icon=MAX_LOGO, fanart=MAX_FANART)
            xbmcplugin.endOfDirectory(HANDLE)
            return
        rows = []
        for block in data_blocks:
            if block.get('paneType') == 'section':
                rows.extend(block.get('section', {}).get('sectionData', {}).get('data', []))
            elif block.get('paneType') == 'content':
                for row in block.get('content', {}).get('dataRows', []):
                    if 'sectionData' in row:
                        rows.extend(row.get('sectionData', {}).get('data', []))
        process_rows(rows, path)
    except: pass
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)

def list_range_episodes(path, code):
    api_url = "https://mmtvmax-api.revlet.net/service/api/v1/section/data"
    params = {'path': path, 'code': code, 'offset': -1}
    try:
        r = requests.get(api_url, params=params, headers=get_headers()).json()
        rows = r.get('response', [{}])[0].get('data', [])
        process_rows(rows, path)
    except: pass
    xbmcplugin.setContent(HANDLE, 'episodes')
    xbmcplugin.endOfDirectory(HANDLE)

def process_rows(rows, path=""):
    """Enhanced parser for high-end skins (Bingie/Netflix Style)."""
    for item in rows:
        display = item.get('display', {})
        target = item.get('target', {})
        attrs = target.get('pageAttributes', {})
        
        title = display.get('title') or display.get('name') or "Unknown"
        asset_id = attrs.get('id')
        if not asset_id: continue

        # 1. FORMAT LABELS
        ep_no = attrs.get('episodeSeqNo')
        label = f"Ep {ep_no}: {title}" if ep_no else title
        
        list_item = xbmcgui.ListItem(label=label)
        
        # 2. 🖼️ BINGIE ARTWORK LOGIC
        # Bingie uses 'thumb' for horizontal rows and 'clearlogo' for the title art.
        poster = display.get('imageUrl')
        landscape = ""
        plot = ""
        
        for elem in item.get('hover', {}).get('elements', []):
            if elem.get('key') == 'description': plot = elem.get('value', '')
            if elem.get('key') == 'bgImage': landscape = elem.get('value')

        list_item.setArt({
            'poster': poster or MAX_LOGO,           # Vertical (Standard)
            'thumb': landscape or poster or MAX_LOGO, # Horizontal (Netflix Rows)
            'fanart': landscape or MAX_FANART,      # Background
            'clearlogo': MAX_LOGO                   # Title Logo (Overlay)
        })

        # 3. ℹ️ RICH METADATA
        # Adding studio and mediatype ensures skin widgets behave correctly.
        content_type = attrs.get('contentType', '').lower()
        info = {
            'title': label,
            'plot': plot,
            'genre': attrs.get('genre', ''),
            'studio': 'ManoramaMAX',                # Shows the brand logo
            'mediatype': 'episode' if ep_no else 'movie' # Critical for skin layouts
        }
        
        # Add year if available in the API
        if '202' in str(item): # Simple regex-like check for date strings
            info['year'] = 2024 

        list_item.setInfo('video', info)
        
        # 4. ROUTING
        if content_type == "tvshowdetails":
            url = f"{BASE_URL}?action=list_page_content&path={target.get('path')}"
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
        else:
            url = f"{BASE_URL}?action=play&id={asset_id}&title={urllib.parse.quote(title)}&path={target.get('path')}"
            list_item.setProperty('IsPlayable', 'true') # Required for Home Screen Widgets
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)

# --- 4. PLAYER (HYBRID HLS/DASH) ---

def play_content(asset_id, title, item_path):
    try:
        stream_api = "https://mmtvmax-api.revlet.net/service/api/v1/page/stream"
        params = {'path': item_path, 'device_supported_features': 'HD,SD,adaptivedvr'}
        r = requests.get(stream_api, params=params, headers=get_headers()).json()
        streams = r.get('response', {}).get('streams', [])
        stream_data = next((s for s in streams if s.get('streamType') == 'akamai'), None)
        manifest_type = 'hls'
        if not stream_data:
            manifest_type = 'mpd'
            stream_data = next((s for s in streams if s.get('streamType') == 'widevine' and s.get('params', {}).get('tags') == 'HD'), None)
            if not stream_data: stream_data = next((s for s in streams if s.get('streamType') == 'widevine'), None)
        if stream_data:
            play_item = xbmcgui.ListItem(label=title, path=stream_data.get('url'))
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.manifest_type', manifest_type)
            license_url = stream_data.get('keys', {}).get('licenseKey')
            if license_url:
                play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                play_item.setProperty('inputstream.adaptive.license_key', license_url + '|Content-Type=application/octet-stream|R{SSM}|')
            xbmcplugin.setResolvedUrl(HANDLE, True, play_item)
    except: xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

def list_search(query):
    api_url = "https://mmtvmax-search.revlet.net/service/api/v3/get/search/query"
    params = {'query': query, 'pageSize': 36, 'last_search_order': 'typesense', 'bucket': 'all'}
    r = requests.get(api_url, params=params, headers=get_headers()).json()
    process_rows(r.get('response', {}).get('searchResults', {}).get('data', []))
    xbmcplugin.endOfDirectory(HANDLE)

def add_dir(name, query, icon=None, fanart=None):
    url = f"{BASE_URL}?" + urllib.parse.urlencode(query)
    list_item = xbmcgui.ListItem(label=name)
    if icon: list_item.setArt({'icon': icon, 'thumb': icon})
    if fanart: list_item.setArt({'fanart': fanart})
    xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)

if __name__ == '__main__':
    args = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    mode = args.get('action')
    if not mode: root_menu()
    elif mode == 'mazhavil_menu': mazhavil_menu()
    elif mode == 'fetch_subsections': fetch_subsections(args['path'])
    elif mode == 'list_page_content': list_page_content(args['path'])
    elif mode == 'list_range_episodes': list_range_episodes(args['path'], args['code'])
    elif mode == 'search_input':
        kb = xbmcgui.Dialog().input('Search Movie', type=xbmcgui.INPUT_ALPHANUM)
        if kb: list_search(kb)
    elif mode == 'play': play_content(args['id'], args.get('title'), args.get('path'))